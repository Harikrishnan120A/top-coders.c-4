/**
 * Authentication middleware for Identity Service
 */

import { Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';

import config from '../config';
import { AuthenticatedRequest, JwtPayload } from '../types';
import { HTTP_STATUS, ERROR_MESSAGES } from '../utils/constants';
import { sendError } from '../utils/helpers';
import logger, { logAuth, logSecurity } from '../utils/logger';

const prisma = new PrismaClient();

/**
 * Middleware to authenticate JWT tokens
 */
export const authenticate = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      logAuth('Authentication failed', undefined, undefined, req.ip, false, 'Missing or invalid authorization header');
      sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
      return;
    }

    const token = authHeader.substring(7); // Remove 'Bearer ' prefix

    try {
      const decoded = jwt.verify(token, config.jwt.secret) as JwtPayload;

      // Verify user still exists and is active
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      if (!user || !user.isActive) {
        logAuth('Authentication failed', decoded.userId, decoded.username, req.ip, false, 'User not found or inactive');
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
        return;
      }

      // Attach user to request (convert null to undefined for type compatibility)
      req.user = {
        ...user,
        firstName: user.firstName ?? undefined,
        lastName: user.lastName ?? undefined,
        lastLoginAt: user.lastLoginAt ?? undefined,
      };
      req.token = token;

      logAuth('Authentication successful', user.id, user.username, req.ip, true);
      next();

    } catch (jwtError: any) {
      if (jwtError.name === 'TokenExpiredError') {
        logAuth('Authentication failed', undefined, undefined, req.ip, false, 'Token expired');
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.TOKEN_EXPIRED);
      } else {
        logAuth('Authentication failed', undefined, undefined, req.ip, false, 'Invalid token');
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.INVALID_TOKEN);
      }
      return;
    }

  } catch (error: any) {
    logger.error('Authentication middleware error:', error);
    sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    return;
  }
};

/**
 * Middleware to check if user has specific role
 */
export const requireRole = (roleName: string) => {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.user) {
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
        return;
      }

      // Check if user has the required role
      const userRole = await prisma.userRole.findFirst({
        where: {
          userId: req.user.id,
          role: {
            name: roleName,
            isActive: true,
          },
        },
        include: {
          role: true,
        },
      });

      if (!userRole) {
        logSecurity('Access denied', 'medium', req.user.id, req.ip, { requiredRole: roleName });
        sendError(res, HTTP_STATUS.FORBIDDEN, ERROR_MESSAGES.FORBIDDEN);
        return;
      }

      next();

    } catch (error: any) {
      logger.error('Role check middleware error:', error);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
      return;
    }
  };
};

/**
 * Middleware to check if user has any of the specified roles
 */
export const requireAnyRole = (roleNames: string[]) => {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.user) {
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
        return;
      }

      // Check if user has any of the required roles
      const userRole = await prisma.userRole.findFirst({
        where: {
          userId: req.user.id,
          role: {
            name: { in: roleNames },
            isActive: true,
          },
        },
        include: {
          role: true,
        },
      });

      if (!userRole) {
        logSecurity('Access denied', 'medium', req.user.id, req.ip, { requiredRoles: roleNames });
        sendError(res, HTTP_STATUS.FORBIDDEN, ERROR_MESSAGES.FORBIDDEN);
        return;
      }

      next();

    } catch (error: any) {
      logger.error('Role check middleware error:', error);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
      return;
    }
  };
};

/**
 * Middleware to check if user owns the resource or has admin role
 */
export const requireOwnershipOrAdmin = (userIdParam: string = 'id') => {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.user) {
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
        return;
      }

      const resourceUserId = req.params[userIdParam];

      // Check if user owns the resource
      if (req.user.id === resourceUserId) {
        next();
        return;
      }

      // Check if user has admin role
      const adminRole = await prisma.userRole.findFirst({
        where: {
          userId: req.user.id,
          role: {
            name: 'admin',
            isActive: true,
          },
        },
      });

      if (!adminRole) {
        logSecurity('Access denied', 'medium', req.user.id, req.ip, {
          resourceUserId,
          reason: 'Not owner and not admin',
        });
        sendError(res, HTTP_STATUS.FORBIDDEN, ERROR_MESSAGES.FORBIDDEN);
        return;
      }

      next();

    } catch (error: any) {
      logger.error('Ownership check middleware error:', error);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
      return;
    }
  };
};

/**
 * Optional authentication middleware (doesn't fail if no token)
 */
export const optionalAuth = async (
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      next();
      return;
    }

    const token = authHeader.substring(7);

    try {
      const decoded = jwt.verify(token, config.jwt.secret) as JwtPayload;

      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      if (user && user.isActive) {
        req.user = {
          ...user,
          firstName: user.firstName ?? undefined,
          lastName: user.lastName ?? undefined,
          lastLoginAt: user.lastLoginAt ?? undefined,
        };
        req.token = token;
      }

    } catch {
      // Silently ignore JWT errors for optional auth
    }

    next();

  } catch (error: any) {
    logger.error('Optional auth middleware error:', error);
    next(); // Continue even if there's an error
  }
};
