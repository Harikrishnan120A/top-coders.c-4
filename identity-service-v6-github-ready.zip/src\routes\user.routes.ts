/**
 * User routes for Identity Service
 */

import { Router } from 'express';
import {
  UserController,
  validateCreateUser,
  validateUpdateUser,
  validateUserQuery,
} from '../controllers/user.controller';
import { authenticate } from '../middleware/auth';

const router = Router();

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * User management routes
 */
router.get('/', validateUserQuery, UserController.getUsers);
router.get('/:id', UserController.getUserById);
router.post('/', validateCreateUser, UserController.createUser);
router.put('/:id', validateUpdateUser, UserController.updateUser);
router.delete('/:id', UserController.deleteUser);

export default router;
