/**
 * Auth Controller for Identity Service
 * Handles authentication-related HTTP requests including login, logout,
 * token refresh, and password management with comprehensive validation
 */

import { Request, Response } from 'express';
import { validationResult, body } from 'express-validator';
import { PrismaClient } from '@prisma/client';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';

import {
  AuthenticatedRequest,
  LoginInput,
  RefreshTokenInput,
  ChangePasswordInput,
  ResetPasswordInput,
  TokenResponse,
} from '../types';
import {
  sendSuccess,
  sendError,
  sendValidationError,
  hashPassword,
  sanitizeUser,
  getClientIp,
  getUserAgent,
} from '../utils/helpers';
import {
  HTTP_STATUS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  VALIDATION_CONSTANTS,
  JWT_CONSTANTS,
} from '../utils/constants';
import {
  logBusiness,
  logError,
  logValidation,
  logSecurity,
} from '../utils/logger';
import config from '../config';

const prisma = new PrismaClient();

/**
 * @swagger
 * components:
 *   schemas:
 *     LoginRequest:
 *       type: object
 *       required:
 *         - username
 *         - password
 *       properties:
 *         username:
 *           type: string
 *           description: Username or email
 *         password:
 *           type: string
 *           description: User password
 *     LoginResponse:
 *       type: object
 *       properties:
 *         accessToken:
 *           type: string
 *           description: JWT access token
 *         refreshToken:
 *           type: string
 *           description: JWT refresh token
 *         user:
 *           $ref: '#/components/schemas/User'
 *         expiresIn:
 *           type: number
 *           description: Token expiration time in seconds
 *     RefreshTokenRequest:
 *       type: object
 *       required:
 *         - refreshToken
 *       properties:
 *         refreshToken:
 *           type: string
 *           description: Valid refresh token
 *     ChangePasswordRequest:
 *       type: object
 *       required:
 *         - currentPassword
 *         - newPassword
 *       properties:
 *         currentPassword:
 *           type: string
 *           description: Current password
 *         newPassword:
 *           type: string
 *           minLength: 8
 *           description: New password
 *     ResetPasswordRequest:
 *       type: object
 *       required:
 *         - token
 *         - newPassword
 *       properties:
 *         token:
 *           type: string
 *           description: Password reset token
 *         newPassword:
 *           type: string
 *           minLength: 8
 *           description: New password
 */

export class AuthController {
  /**
   * @swagger
   * /api/v1/auth/login:
   *   post:
   *     summary: Authenticate user and return tokens
   *     tags: [Authentication]
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/LoginRequest'
   *     responses:
   *       200:
   *         description: Login successful
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                 data:
   *                   $ref: '#/components/schemas/LoginResponse'
   *                 message:
   *                   type: string
   *       401:
   *         description: Invalid credentials
   *       400:
   *         description: Validation error
   *       500:
   *         description: Internal server error
   */
  public static async login(req: Request, res: Response): Promise<void> {
    try {
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        logValidation('username', req.body.username, 'Invalid login request');
        sendValidationError(res, errors.array().map(err => ({
          field: err.type === 'field' ? err.path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? err.value : undefined,
        })));
        return;
      }

      const { username, password }: LoginInput = req.body;
      const clientIp = getClientIp(req);
      const userAgent = getUserAgent(req);

      // Find user by username or email
      const user = await prisma.user.findFirst({
        where: {
          OR: [
            { username: { equals: username, mode: 'insensitive' } },
            { email: { equals: username, mode: 'insensitive' } },
          ],
        },
        include: {
          userRoles: {
            include: {
              role: true,
            },
          },
        },
      });

      if (!user) {
        logSecurity('Login attempt with invalid username', 'medium', undefined, clientIp, { username, userAgent });
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.INVALID_CREDENTIALS);
        return;
      }

      if (!user.isActive) {
        logSecurity('Login attempt with inactive user', 'medium', user.id, clientIp, { username, userAgent });
        sendError(res, HTTP_STATUS.UNAUTHORIZED, 'Account is inactive');
        return;
      }

      // Verify password
      const isPasswordValid = await bcrypt.compare(password, user.password);
      if (!isPasswordValid) {
        logSecurity('Login attempt with invalid password', 'medium', user.id, clientIp, { username, userAgent });
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.INVALID_CREDENTIALS);
        return;
      }

      // Generate tokens
      const accessToken = AuthController.generateAccessToken(user);
      const refreshToken = AuthController.generateRefreshToken(user);

      // Store refresh token
      await prisma.authToken.create({
        data: {
          userId: user.id,
          token: refreshToken,
          tokenType: 'REFRESH',
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        },
      });

      // Update last login
      await prisma.user.update({
        where: { id: user.id },
        data: { lastLoginAt: new Date() },
      });

      // Prepare response
      const tokenResponse: TokenResponse = {
        accessToken,
        refreshToken,
        user: sanitizeUser(user),
        expiresIn: 24 * 60 * 60, // 24 hours in seconds
      };

      logBusiness('User logged in', 'user', user.id, user.id, {
        username: user.username,
        clientIp,
        userAgent,
      });

      sendSuccess(res, tokenResponse, SUCCESS_MESSAGES.LOGIN_SUCCESS, HTTP_STATUS.OK);
    } catch (error: any) {
      logError(error, { action: 'login', username: req.body.username });
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/auth/refresh:
   *   post:
   *     summary: Refresh access token using refresh token
   *     tags: [Authentication]
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/RefreshTokenRequest'
   *     responses:
   *       200:
   *         description: Token refreshed successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                 data:
   *                   $ref: '#/components/schemas/LoginResponse'
   *                 message:
   *                   type: string
   *       401:
   *         description: Invalid or expired refresh token
   *       400:
   *         description: Validation error
   *       500:
   *         description: Internal server error
   */
  public static async refreshToken(req: Request, res: Response): Promise<void> {
    try {
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        logValidation('refreshToken', req.body.refreshToken, 'Invalid refresh token request');
        sendValidationError(res, errors.array().map(err => ({
          field: err.type === 'field' ? err.path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? err.value : undefined,
        })));
        return;
      }

      const { refreshToken }: RefreshTokenInput = req.body;
      const clientIp = getClientIp(req);
      const userAgent = getUserAgent(req);

      // Verify refresh token
      let decoded: any;
      try {
        decoded = jwt.verify(refreshToken, config.jwt.refreshSecret);
      } catch {
        logSecurity('Invalid refresh token attempt', 'medium', undefined, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.INVALID_TOKEN);
        return;
      }

      // Check if token exists in database and is not revoked
      const storedToken = await prisma.authToken.findFirst({
        where: {
          token: refreshToken,
          userId: decoded.userId,
          tokenType: 'REFRESH',
          isRevoked: false,
          expiresAt: {
            gt: new Date(),
          },
        },
      });

      if (!storedToken) {
        logSecurity('Refresh token not found or expired', 'medium', decoded.userId, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.INVALID_TOKEN);
        return;
      }

      // Get user with roles
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        include: {
          userRoles: {
            include: {
              role: true,
            },
          },
        },
      });

      if (!user || !user.isActive) {
        logSecurity('Refresh token for inactive/missing user', 'medium', decoded.userId, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.INVALID_TOKEN);
        return;
      }

      // Generate new tokens
      const newAccessToken = AuthController.generateAccessToken(user);
      const newRefreshToken = AuthController.generateRefreshToken(user);

      // Revoke old refresh token
      await prisma.authToken.update({
        where: { id: storedToken.id },
        data: { isRevoked: true },
      });

      // Store new refresh token
      await prisma.authToken.create({
        data: {
          userId: user.id,
          token: newRefreshToken,
          tokenType: 'REFRESH',
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
        },
      });

      // Prepare response
      const tokenResponse: TokenResponse = {
        accessToken: newAccessToken,
        refreshToken: newRefreshToken,
        user: sanitizeUser(user),
        expiresIn: 24 * 60 * 60, // 24 hours in seconds
      };

      logBusiness('Token refreshed', 'user', user.id, user.id, {
        username: user.username,
        clientIp,
        userAgent,
      });

      sendSuccess(res, tokenResponse, 'Token refreshed successfully', HTTP_STATUS.OK);
    } catch (error: any) {
      logError(error, { action: 'refreshToken' });
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/auth/logout:
   *   post:
   *     summary: Logout user and revoke tokens
   *     tags: [Authentication]
   *     security:
   *       - bearerAuth: []
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             type: object
   *             properties:
   *               refreshToken:
   *                 type: string
   *                 description: Refresh token to revoke
   *     responses:
   *       200:
   *         description: Logout successful
   *       401:
   *         description: Unauthorized
   *       500:
   *         description: Internal server error
   */
  public static async logout(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { refreshToken } = req.body;
      const userId = req.user?.id;
      const clientIp = getClientIp(req);
      const userAgent = getUserAgent(req);

      if (!userId) {
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
        return;
      }

      // Revoke specific refresh token if provided
      if (refreshToken) {
        await prisma.authToken.updateMany({
          where: {
            token: refreshToken,
            userId,
            tokenType: 'REFRESH',
            isRevoked: false,
          },
          data: { isRevoked: true },
        });
      } else {
        // Revoke all refresh tokens for user
        await prisma.authToken.updateMany({
          where: {
            userId,
            tokenType: 'REFRESH',
            isRevoked: false,
          },
          data: { isRevoked: true },
        });
      }

      logBusiness('User logged out', 'user', userId, userId, {
        revokedSpecificToken: !!refreshToken,
        clientIp,
        userAgent,
      });

      sendSuccess(res, null, SUCCESS_MESSAGES.LOGOUT_SUCCESS, HTTP_STATUS.OK);
    } catch (error: any) {
      logError(error, { action: 'logout', userId: req.user?.id });
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/auth/change-password:
   *   post:
   *     summary: Change user password
   *     tags: [Authentication]
   *     security:
   *       - bearerAuth: []
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/ChangePasswordRequest'
   *     responses:
   *       200:
   *         description: Password changed successfully
   *       400:
   *         description: Validation error or invalid current password
   *       401:
   *         description: Unauthorized
   *       500:
   *         description: Internal server error
   */
  public static async changePassword(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        logValidation('password', req.body.newPassword, 'Invalid change password request', req.user?.id);
        sendValidationError(res, errors.array().map(err => ({
          field: err.type === 'field' ? err.path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? err.value : undefined,
        })));
        return;
      }

      const { currentPassword, newPassword }: ChangePasswordInput = req.body;
      const userId = req.user?.id;
      const clientIp = getClientIp(req);
      const userAgent = getUserAgent(req);

      if (!userId) {
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
        return;
      }

      // Get user with current password
      const user = await prisma.user.findUnique({
        where: { id: userId },
      });

      if (!user) {
        logSecurity('Change password attempt for non-existent user', 'high', userId, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.USER_NOT_FOUND);
        return;
      }

      // Verify current password
      const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.password);
      if (!isCurrentPasswordValid) {
        logSecurity('Change password attempt with invalid current password', 'medium', userId, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Current password is incorrect');
        return;
      }

      // Hash new password
      const hashedNewPassword = await hashPassword(newPassword);

      // Update password
      await prisma.user.update({
        where: { id: userId },
        data: { password: hashedNewPassword },
      });

      // Revoke all refresh tokens to force re-login
      await prisma.authToken.updateMany({
        where: {
          userId,
          tokenType: 'REFRESH',
          isRevoked: false,
        },
        data: { isRevoked: true },
      });

      logBusiness('Password changed', 'user', userId, userId, {
        clientIp,
        userAgent,
      });

      sendSuccess(res, null, 'Password changed successfully', HTTP_STATUS.OK);
    } catch (error: any) {
      logError(error, { action: 'changePassword', userId: req.user?.id });
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/auth/forgot-password:
   *   post:
   *     summary: Request password reset
   *     tags: [Authentication]
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             type: object
   *             required:
   *               - email
   *             properties:
   *               email:
   *                 type: string
   *                 format: email
   *                 description: User email address
   *     responses:
   *       200:
   *         description: Password reset email sent (always returns success for security)
   *       400:
   *         description: Validation error
   *       500:
   *         description: Internal server error
   */
  public static async forgotPassword(req: Request, res: Response): Promise<void> {
    try {
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        logValidation('email', req.body.email, 'Invalid forgot password request');
        sendValidationError(res, errors.array().map(err => ({
          field: err.type === 'field' ? err.path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? err.value : undefined,
        })));
        return;
      }

      const { email } = req.body;
      const clientIp = getClientIp(req);
      const userAgent = getUserAgent(req);

      // Find user by email
      const user = await prisma.user.findFirst({
        where: { email: { equals: email, mode: 'insensitive' } },
      });

      // Always return success for security (don't reveal if email exists)
      if (user && user.isActive) {
        // Generate reset token
        const resetToken = jwt.sign(
          { userId: user.id, type: 'password-reset' },
          config.jwt.secret,
          { expiresIn: '1h' },
        );

        // Store reset token
        await prisma.authToken.create({
          data: {
            userId: user.id,
            token: resetToken,
            tokenType: 'RESET_PASSWORD',
            expiresAt: new Date(Date.now() + 60 * 60 * 1000), // 1 hour
          },
        });

        logBusiness('Password reset requested', 'user', user.id, user.id, {
          email,
          clientIp,
          userAgent,
        });

        // TODO: Send email with reset link
        // await emailService.sendPasswordResetEmail(email, resetToken);
      } else {
        logSecurity('Password reset requested for non-existent/inactive user', 'low', undefined, clientIp, { email, userAgent });
      }

      sendSuccess(res, null, 'If the email exists, a password reset link has been sent', HTTP_STATUS.OK);
    } catch (error: any) {
      logError(error, { action: 'forgotPassword', email: req.body.email });
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/auth/reset-password:
   *   post:
   *     summary: Reset password using reset token
   *     tags: [Authentication]
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/ResetPasswordRequest'
   *     responses:
   *       200:
   *         description: Password reset successfully
   *       400:
   *         description: Validation error or invalid token
   *       500:
   *         description: Internal server error
   */
  public static async resetPassword(req: Request, res: Response): Promise<void> {
    try {
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        logValidation('token', req.body.token, 'Invalid reset password request');
        sendValidationError(res, errors.array().map(err => ({
          field: err.type === 'field' ? err.path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? err.value : undefined,
        })));
        return;
      }

      const { token, newPassword }: ResetPasswordInput = req.body;
      const clientIp = getClientIp(req);
      const userAgent = getUserAgent(req);

      // Verify reset token
      let decoded: any;
      try {
        decoded = jwt.verify(token, config.jwt.secret);
      } catch {
        logSecurity('Invalid password reset token attempt', 'medium', undefined, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Invalid or expired reset token');
        return;
      }

      if (decoded.type !== 'password-reset') {
        logSecurity('Invalid password reset token type', 'high', undefined, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Invalid reset token');
        return;
      }

      // Check if token exists in database and is not revoked
      const storedToken = await prisma.authToken.findFirst({
        where: {
          token,
          userId: decoded.userId,
          tokenType: 'RESET_PASSWORD',
          isRevoked: false,
          expiresAt: {
            gt: new Date(),
          },
        },
      });

      if (!storedToken) {
        logSecurity('Password reset token not found or expired', 'medium', decoded.userId, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Invalid or expired reset token');
        return;
      }

      // Get user
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
      });

      if (!user || !user.isActive) {
        logSecurity('Password reset for inactive/missing user', 'high', decoded.userId, clientIp, { userAgent });
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Invalid reset token');
        return;
      }

      // Hash new password
      const hashedNewPassword = await hashPassword(newPassword);

      // Update password and revoke reset token
      await prisma.$transaction(async (tx) => {
        // Update password
        await tx.user.update({
          where: { id: user.id },
          data: { password: hashedNewPassword },
        });

        // Revoke reset token
        await tx.authToken.update({
          where: { id: storedToken.id },
          data: { isRevoked: true },
        });

        // Revoke all refresh tokens to force re-login
        await tx.authToken.updateMany({
          where: {
            userId: user.id,
            tokenType: 'REFRESH',
            isRevoked: false,
          },
          data: { isRevoked: true },
        });
      });

      logBusiness('Password reset completed', 'user', user.id, user.id, {
        clientIp,
        userAgent,
      });

      sendSuccess(res, null, 'Password reset successfully', HTTP_STATUS.OK);
    } catch (error: any) {
      logError(error, { action: 'resetPassword' });
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/auth/me:
   *   get:
   *     summary: Get current user profile
   *     tags: [Authentication]
   *     security:
   *       - bearerAuth: []
   *     responses:
   *       200:
   *         description: Current user profile
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                 data:
   *                   $ref: '#/components/schemas/User'
   *                 message:
   *                   type: string
   *       401:
   *         description: Unauthorized
   *       500:
   *         description: Internal server error
   */
  public static async getCurrentUser(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const userId = req.user?.id;

      if (!userId) {
        sendError(res, HTTP_STATUS.UNAUTHORIZED, ERROR_MESSAGES.UNAUTHORIZED);
        return;
      }

      // Get user with roles
      const user = await prisma.user.findUnique({
        where: { id: userId },
        include: {
          userRoles: {
            include: {
              role: true,
            },
          },
        },
      });

      if (!user) {
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.USER_NOT_FOUND);
        return;
      }

      logBusiness('Current user profile retrieved', 'user', userId, userId);
      sendSuccess(res, sanitizeUser(user), 'Current user profile retrieved', HTTP_STATUS.OK);
    } catch (error: any) {
      logError(error, { action: 'getCurrentUser', userId: req.user?.id });
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  // Helper methods for token generation
  private static generateAccessToken(user: any): string {
    const payload = {
      userId: user.id,
      username: user.username,
      email: user.email,
      roles: user.userRoles.map((ur: any) => ur.role.name),
      type: 'access',
    };

    return jwt.sign(payload, config.jwt.secret, {
      expiresIn: JWT_CONSTANTS.DEFAULT_EXPIRY,
      issuer: JWT_CONSTANTS.ISSUER,
    });
  }

  private static generateRefreshToken(user: any): string {
    const payload = {
      userId: user.id,
      type: 'refresh',
    };

    return jwt.sign(payload, config.jwt.refreshSecret, {
      expiresIn: JWT_CONSTANTS.REFRESH_TOKEN_EXPIRY,
      issuer: JWT_CONSTANTS.ISSUER,
    });
  }
}

// Validation middleware for auth operations
export const validateLogin = [
  body('username')
    .isLength({ min: 1 })
    .withMessage('Username or email is required')
    .trim(),
  body('password')
    .isLength({ min: 1 })
    .withMessage('Password is required'),
];

export const validateRefreshToken = [
  body('refreshToken')
    .isString()
    .notEmpty()
    .withMessage('Refresh token is required'),
];

export const validateChangePassword = [
  body('currentPassword')
    .isLength({ min: 1 })
    .withMessage('Current password is required'),
  body('newPassword')
    .isLength({ min: VALIDATION_CONSTANTS.MIN_PASSWORD_LENGTH, max: VALIDATION_CONSTANTS.MAX_PASSWORD_LENGTH })
    .withMessage(`New password must be between ${VALIDATION_CONSTANTS.MIN_PASSWORD_LENGTH} and ${VALIDATION_CONSTANTS.MAX_PASSWORD_LENGTH} characters`)
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('New password must contain at least one lowercase letter, one uppercase letter, and one number'),
];

export const validateForgotPassword = [
  body('email')
    .isEmail()
    .withMessage('Valid email is required')
    .normalizeEmail(),
];

export const validateResetPassword = [
  body('token')
    .isString()
    .notEmpty()
    .withMessage('Reset token is required'),
  body('newPassword')
    .isLength({ min: VALIDATION_CONSTANTS.MIN_PASSWORD_LENGTH, max: VALIDATION_CONSTANTS.MAX_PASSWORD_LENGTH })
    .withMessage(`New password must be between ${VALIDATION_CONSTANTS.MIN_PASSWORD_LENGTH} and ${VALIDATION_CONSTANTS.MAX_PASSWORD_LENGTH} characters`)
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('New password must contain at least one lowercase letter, one uppercase letter, and one number'),
];
