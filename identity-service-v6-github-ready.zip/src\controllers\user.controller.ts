/**
 import { Response } from 'express';
import { validationResult, body, param, query } from 'express-validator';
import { PrismaClient, Prisma } from '@prisma/client';ser Controller for Identity Service
 * Handles all user-related HTTP requests with comprehensive validation,
 * error handling, and API documentation
 */

import { Response } from 'express';
import { validationResult, body, param, query } from 'express-validator';
import { PrismaClient } from '@prisma/client';

import {
  AuthenticatedRequest,
  CreateUserInput,
  UpdateUserInput,
  UserQuery,
} from '../types';
import {
  sendSuccess,
  sendError,
  sendValidationError,
  parsePaginationQuery,
  getPaginationMeta,
  getOffset,
  hashPassword,
  sanitizeUser,
  getClientIp,
  getUserAgent,
} from '../utils/helpers';
import {
  HTTP_STATUS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  VALIDATION_CONSTANTS,
} from '../utils/constants';
import {
  logBusiness,
  logError,
  logValidation,
} from '../utils/logger';

const prisma = new PrismaClient();

/**
 * @swagger
 * components:
 *   schemas:
 *     User:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: Unique identifier for the user
 *         username:
 *           type: string
 *           description: User's username (unique)
 *         email:
 *           type: string
 *           format: email
 *           description: User's email address (unique)
 *         firstName:
 *           type: string
 *           description: User's first name
 *         lastName:
 *           type: string
 *           description: User's last name
 *         isActive:
 *           type: boolean
 *           description: Whether the user account is active
 *         lastLoginAt:
 *           type: string
 *           format: date-time
 *           description: Last login timestamp
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Account creation timestamp
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           description: Last update timestamp
 *     CreateUserRequest:
 *       type: object
 *       required:
 *         - username
 *         - email
 *         - password
 *       properties:
 *         username:
 *           type: string
 *           minLength: 3
 *           maxLength: 50
 *           pattern: '^[a-zA-Z0-9_-]+$'
 *         email:
 *           type: string
 *           format: email
 *           maxLength: 255
 *         password:
 *           type: string
 *           minLength: 8
 *           maxLength: 128
 *         firstName:
 *           type: string
 *           maxLength: 100
 *         lastName:
 *           type: string
 *           maxLength: 100
 */

export class UserController {
  /**
   * @swagger
   * /api/v1/users:
   *   get:
   *     summary: Get all users with pagination and filtering
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: query
   *         name: page
   *         schema:
   *           type: integer
   *           minimum: 1
   *           default: 1
   *         description: Page number
   *       - in: query
   *         name: limit
   *         schema:
   *           type: integer
   *           minimum: 1
   *           maximum: 100
   *           default: 20
   *         description: Number of items per page
   *       - in: query
   *         name: search
   *         schema:
   *           type: string
   *         description: Search term for username or email
   *       - in: query
   *         name: isActive
   *         schema:
   *           type: boolean
   *         description: Filter by active status
   *       - in: query
   *         name: sortBy
   *         schema:
   *           type: string
   *           enum: [username, email, createdAt, lastLoginAt]
   *           default: createdAt
   *         description: Field to sort by
   *       - in: query
   *         name: sortOrder
   *         schema:
   *           type: string
   *           enum: [asc, desc]
   *           default: desc
   *         description: Sort order
   *     responses:
   *       200:
   *         description: List of users retrieved successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                   example: true
   *                 data:
   *                   type: array
   *                   items:
   *                     $ref: '#/components/schemas/User'
   *                 meta:
   *                   $ref: '#/components/schemas/PaginationMeta'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async getUsers(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { page, limit, sortBy, sortOrder } = parsePaginationQuery(req.query);
      const { search, isActive } = req.query as UserQuery;
      const offset = getOffset(page, limit);

      // Build where clause for filtering
      const where: any = {};

      if (search) {
        where.OR = [
          { username: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
        ];
      }

      if (isActive !== undefined) {
        where.isActive = isActive === 'true';
      }

      // Get users with pagination
      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          select: {
            id: true,
            username: true,
            email: true,
            firstName: true,
            lastName: true,
            isActive: true,
            lastLoginAt: true,
            createdAt: true,
            updatedAt: true,
          },
          orderBy: { [sortBy]: sortOrder },
          skip: offset,
          take: limit,
        }),
        prisma.user.count({ where }),
      ]);

      // Convert null to undefined for type compatibility
      const sanitizedUsers = users.map(user => ({
        ...user,
        firstName: user.firstName ?? undefined,
        lastName: user.lastName ?? undefined,
        lastLoginAt: user.lastLoginAt ?? undefined,
      }));

      const meta = getPaginationMeta(page, limit, total);

      logBusiness('getUsers', 'user', 'list', req.user?.id, {
        total,
        page,
        limit,
        search,
        isActive,
      });

      sendSuccess(res, sanitizedUsers, 'Users retrieved successfully', HTTP_STATUS.OK, meta);
    } catch (error: any) {
      logError(error, { action: 'getUsers' }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/users/{id}:
   *   get:
   *     summary: Get user by ID
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema:
   *           type: string
   *         description: User ID
   *     responses:
   *       200:
   *         description: User retrieved successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                   example: true
   *                 data:
   *                   $ref: '#/components/schemas/User'
   *       404:
   *         $ref: '#/components/responses/NotFound'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async getUserById(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { id } = req.params;

      const user = await prisma.user.findUnique({
        where: { id },
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
          userRoles: {
            include: {
              role: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                  isActive: true,
                },
              },
            },
          },
        },
      });

      if (!user) {
        logBusiness('getUserById', 'user', id, req.user?.id, undefined, ERROR_MESSAGES.USER_NOT_FOUND);
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.USER_NOT_FOUND);
        return;
      }

      // Convert null to undefined and sanitize
      const sanitizedUser = {
        ...user,
        firstName: user.firstName ?? undefined,
        lastName: user.lastName ?? undefined,
        lastLoginAt: user.lastLoginAt ?? undefined,
      };

      logBusiness('getUserById', 'user', id, req.user?.id);
      sendSuccess(res, sanitizedUser, 'User retrieved successfully');
    } catch (error: any) {
      logError(error, { action: 'getUserById', userId: req.params.id }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/users:
   *   post:
   *     summary: Create a new user
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/CreateUserRequest'
   *     responses:
   *       201:
   *         description: User created successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                   example: true
   *                 data:
   *                   $ref: '#/components/schemas/User'
   *                 message:
   *                   type: string
   *                   example: User created successfully
   *       400:
   *         $ref: '#/components/responses/BadRequest'
   *       409:
   *         $ref: '#/components/responses/Conflict'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async createUser(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        const validationErrors = errors.array().map(err => ({
          field: err.type === 'field' ? (err as any).path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? (err as any).value : undefined,
        }));

        validationErrors.forEach(error => {
          logValidation(error.field, error.value, error.message, req.user?.id);
        });

        sendValidationError(res, validationErrors);
        return;
      }

      const userData: CreateUserInput = req.body;

      // Check for existing username or email
      const existingUser = await prisma.user.findFirst({
        where: {
          OR: [
            { username: userData.username },
            { email: userData.email },
          ],
        },
      });

      if (existingUser) {
        const conflictField = existingUser.username === userData.username ? 'username' : 'email';
        logBusiness('createUser', 'user', 'create_conflict', req.user?.id, {
          conflictField,
          attemptedValue: conflictField === 'username' ? userData.username : userData.email,
        });
        sendError(res, HTTP_STATUS.CONFLICT, `User with this ${conflictField} already exists`);
        return;
      }

      // Hash password
      const hashedPassword = await hashPassword(userData.password);

      // Create user
      const newUser = await prisma.user.create({
        data: {
          username: userData.username,
          email: userData.email,
          password: hashedPassword,
          firstName: userData.firstName,
          lastName: userData.lastName,
        },
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      // Convert null to undefined
      const sanitizedUser = {
        ...newUser,
        firstName: newUser.firstName ?? undefined,
        lastName: newUser.lastName ?? undefined,
        lastLoginAt: newUser.lastLoginAt ?? undefined,
      };

      // Log audit trail
      await prisma.auditLog.create({
        data: {
          entityType: 'user',
          entityId: newUser.id,
          action: 'create',
          newValues: sanitizeUser(sanitizedUser),
          userId: req.user?.id,
          ipAddress: getClientIp(req),
          userAgent: getUserAgent(req),
        },
      });

      logBusiness('createUser', 'user', newUser.id, req.user?.id, { username: newUser.username });
      sendSuccess(res, sanitizedUser, SUCCESS_MESSAGES.USER_CREATED, HTTP_STATUS.CREATED);
    } catch (error: any) {
      logError(error, { action: 'createUser', userData: req.body }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/users/{id}:
   *   put:
   *     summary: Update user by ID
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema:
   *           type: string
   *         description: User ID
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             type: object
   *             properties:
   *               username:
   *                 type: string
   *                 minLength: 3
   *                 maxLength: 50
   *               email:
   *                 type: string
   *                 format: email
   *                 maxLength: 255
   *               firstName:
   *                 type: string
   *                 maxLength: 100
   *               lastName:
   *                 type: string
   *                 maxLength: 100
   *               isActive:
   *                 type: boolean
   *     responses:
   *       200:
   *         description: User updated successfully
   *       404:
   *         $ref: '#/components/responses/NotFound'
   *       409:
   *         $ref: '#/components/responses/Conflict'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async updateUser(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updateData: UpdateUserInput = req.body;

      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        const validationErrors = errors.array().map(err => ({
          field: err.type === 'field' ? (err as any).path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? (err as any).value : undefined,
        }));
        sendValidationError(res, validationErrors);
        return;
      }

      // Check if user exists
      const existingUser = await prisma.user.findUnique({
        where: { id },
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      if (!existingUser) {
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.USER_NOT_FOUND);
        return;
      }

      // Check for username/email conflicts (if being updated)
      if (updateData.username || updateData.email) {
        const conflictWhere: any = {
          AND: [
            { id: { not: id } },
            {
              OR: [],
            },
          ],
        };

        if (updateData.username) {
          conflictWhere.AND[1].OR.push({ username: updateData.username });
        }
        if (updateData.email) {
          conflictWhere.AND[1].OR.push({ email: updateData.email });
        }

        const conflictUser = await prisma.user.findFirst({ where: conflictWhere });
        if (conflictUser) {
          const conflictField = conflictUser.username === updateData.username ? 'username' : 'email';
          sendError(res, HTTP_STATUS.CONFLICT, `User with this ${conflictField} already exists`);
          return;
        }
      }

      // Update user
      const updatedUser = await prisma.user.update({
        where: { id },
        data: updateData,
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      // Convert null to undefined
      const sanitizedUser = {
        ...updatedUser,
        firstName: updatedUser.firstName ?? undefined,
        lastName: updatedUser.lastName ?? undefined,
        lastLoginAt: updatedUser.lastLoginAt ?? undefined,
      };

      const sanitizedExistingUser = {
        ...existingUser,
        firstName: existingUser.firstName ?? undefined,
        lastName: existingUser.lastName ?? undefined,
        lastLoginAt: existingUser.lastLoginAt ?? undefined,
      };

      // Log audit trail
      await prisma.auditLog.create({
        data: {
          entityType: 'user',
          entityId: id,
          action: 'update',
          oldValues: sanitizeUser(sanitizedExistingUser),
          newValues: sanitizeUser(sanitizedUser),
          userId: req.user?.id,
          ipAddress: getClientIp(req),
          userAgent: getUserAgent(req),
        },
      });

      logBusiness('updateUser', 'user', id, req.user?.id, { changes: updateData });
      sendSuccess(res, sanitizedUser, SUCCESS_MESSAGES.USER_UPDATED);
    } catch (error: any) {
      logError(error, { action: 'updateUser', userId: req.params.id }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/users/{id}:
   *   delete:
   *     summary: Delete user by ID
   *     tags: [Users]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema:
   *           type: string
   *         description: User ID
   *     responses:
   *       204:
   *         description: User deleted successfully
   *       404:
   *         $ref: '#/components/responses/NotFound'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async deleteUser(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { id } = req.params;

      // Check if user exists
      const existingUser = await prisma.user.findUnique({
        where: { id },
        select: {
          id: true,
          username: true,
          email: true,
          firstName: true,
          lastName: true,
          isActive: true,
          lastLoginAt: true,
          createdAt: true,
          updatedAt: true,
        },
      });

      if (!existingUser) {
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.USER_NOT_FOUND);
        return;
      }

      // Prevent self-deletion
      if (req.user?.id === id) {
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Cannot delete your own account');
        return;
      }

      // Use transaction to ensure data consistency
      await prisma.$transaction(async (tx) => {
        // Delete related records first (cascade should handle this, but being explicit)
        await tx.userRole.deleteMany({ where: { userId: id } });
        await tx.groupMember.deleteMany({ where: { userId: id } });
        await tx.authToken.deleteMany({ where: { userId: id } });

        // Delete the user
        await tx.user.delete({ where: { id } });

        // Log audit trail
        await tx.auditLog.create({
          data: {
            entityType: 'user',
            entityId: id,
            action: 'delete',
            oldValues: sanitizeUser(existingUser),
            userId: req.user?.id,
            ipAddress: getClientIp(req),
            userAgent: getUserAgent(req),
          },
        });
      });

      logBusiness('deleteUser', 'user', id, req.user?.id, { username: existingUser.username });
      sendSuccess(res, undefined, SUCCESS_MESSAGES.USER_DELETED, HTTP_STATUS.NO_CONTENT);
    } catch (error: any) {
      logError(error, { action: 'deleteUser', userId: req.params.id }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }
}

// Validation middleware for user operations
export const validateCreateUser = [
  body('username')
    .isLength({ min: VALIDATION_CONSTANTS.MIN_USERNAME_LENGTH, max: VALIDATION_CONSTANTS.MAX_USERNAME_LENGTH })
    .withMessage(`Username must be between ${VALIDATION_CONSTANTS.MIN_USERNAME_LENGTH} and ${VALIDATION_CONSTANTS.MAX_USERNAME_LENGTH} characters`)
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('Username can only contain letters, numbers, underscores, and hyphens'),

  body('email')
    .isEmail()
    .withMessage('Invalid email format')
    .isLength({ max: VALIDATION_CONSTANTS.MAX_EMAIL_LENGTH })
    .withMessage(`Email must not exceed ${VALIDATION_CONSTANTS.MAX_EMAIL_LENGTH} characters`)
    .normalizeEmail(),

  body('password')
    .isLength({ min: VALIDATION_CONSTANTS.MIN_PASSWORD_LENGTH, max: VALIDATION_CONSTANTS.MAX_PASSWORD_LENGTH })
    .withMessage(`Password must be between ${VALIDATION_CONSTANTS.MIN_PASSWORD_LENGTH} and ${VALIDATION_CONSTANTS.MAX_PASSWORD_LENGTH} characters`)
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number'),

  body('firstName')
    .optional()
    .isLength({ max: VALIDATION_CONSTANTS.MAX_NAME_LENGTH })
    .withMessage(`First name must not exceed ${VALIDATION_CONSTANTS.MAX_NAME_LENGTH} characters`)
    .trim(),

  body('lastName')
    .optional()
    .isLength({ max: VALIDATION_CONSTANTS.MAX_NAME_LENGTH })
    .withMessage(`Last name must not exceed ${VALIDATION_CONSTANTS.MAX_NAME_LENGTH} characters`)
    .trim(),
];

export const validateUpdateUser = [
  param('id').isUUID().withMessage('Invalid user ID format'),

  body('username')
    .optional()
    .isLength({ min: VALIDATION_CONSTANTS.MIN_USERNAME_LENGTH, max: VALIDATION_CONSTANTS.MAX_USERNAME_LENGTH })
    .withMessage(`Username must be between ${VALIDATION_CONSTANTS.MIN_USERNAME_LENGTH} and ${VALIDATION_CONSTANTS.MAX_USERNAME_LENGTH} characters`)
    .matches(/^[a-zA-Z0-9_-]+$/)
    .withMessage('Username can only contain letters, numbers, underscores, and hyphens'),

  body('email')
    .optional()
    .isEmail()
    .withMessage('Invalid email format')
    .isLength({ max: VALIDATION_CONSTANTS.MAX_EMAIL_LENGTH })
    .withMessage(`Email must not exceed ${VALIDATION_CONSTANTS.MAX_EMAIL_LENGTH} characters`)
    .normalizeEmail(),

  body('firstName')
    .optional()
    .isLength({ max: VALIDATION_CONSTANTS.MAX_NAME_LENGTH })
    .withMessage(`First name must not exceed ${VALIDATION_CONSTANTS.MAX_NAME_LENGTH} characters`)
    .trim(),

  body('lastName')
    .optional()
    .isLength({ max: VALIDATION_CONSTANTS.MAX_NAME_LENGTH })
    .withMessage(`Last name must not exceed ${VALIDATION_CONSTANTS.MAX_NAME_LENGTH} characters`)
    .trim(),

  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean value'),
];

export const validateUserParams = [
  param('id').isUUID().withMessage('Invalid user ID format'),
];

export const validateUserQuery = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('search').optional().isLength({ max: 100 }).withMessage('Search term too long'),
  query('isActive').optional().isBoolean().withMessage('isActive must be a boolean'),
  query('sortBy').optional().isIn(['username', 'email', 'createdAt', 'lastLoginAt']).withMessage('Invalid sort field'),
  query('sortOrder').optional().isIn(['asc', 'desc']).withMessage('Sort order must be asc or desc'),
];
