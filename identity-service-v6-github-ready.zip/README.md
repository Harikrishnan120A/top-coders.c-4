# 🔐 Identity Service v6

[![Build Status](https://img.shields.io/github/workflow/status/topcoder/identity-service-v6/CI)](https://github.com/topcoder/identity-service-v6/actions)
[![Coverage](https://img.shields.io/codecov/c/github/topcoder/identity-service-v6)](https://codecov.io/gh/topcoder/identity-service-v6)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.3-blue.svg)](https://www.typescriptlang.org/)
[![Node.js](https://img.shields.io/badge/Node.js-18+-green.svg)](https://nodejs.org/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16.3-blue.svg)](https://www.postgresql.org/)

> **Enterprise-grade identity and authentication service** for the Topcoder platform, built with modern TypeScript architecture. Migrated from legacy Java/MySQL to a scalable TypeScript/PostgreSQL solution using Prisma ORM.

<p align="center">
  <img src="https://img.shields.io/github/stars/topcoder/identity-service-v6?style=social" alt="Stars" />
  <img src="https://img.shields.io/github/forks/topcoder/identity-service-v6?style=social" alt="Forks" />
  <img src="https://img.shields.io/github/issues/topcoder/identity-service-v6" alt="Issues" />
</p>

---

---

## � Table of Contents

- [✨ Features](#-features)
- [🛠 Technology Stack](#-technology-stack)
- [📋 Prerequisites](#-prerequisites)
- [🚀 Quick Start](#-quick-start)
- [🔧 Installation & Setup](#-installation--setup)
- [🏃‍♂️ Running the Application](#️-running-the-application)
- [🧪 Testing](#-testing)
- [📚 API Documentation](#-api-documentation)
- [🐳 Docker Support](#-docker-support)
- [🚀 Deployment](#-deployment)
- [🤝 Contributing](#-contributing)
- [📄 License](#-license)
- [🆘 Troubleshooting](#-troubleshooting)

---

## ✨ Features

<table>
<tr>
<td>

**🔐 Authentication & Security**
- JWT-based authentication
- Role-based access control (RBAC)
- Rate limiting & security best practices
- Password hashing with bcrypt

</td>
<td>

**👥 User Management**
- Complete CRUD operations
- Profile management
- User search & filtering
- Account activation/deactivation

</td>
</tr>
<tr>
<td>

**🎭 Role & Group Management**
- Dynamic role creation & assignment
- Unique name constraints
- Group membership management
- Privacy controls

</td>
<td>

**🚀 Performance & Scalability**
- Redis caching layer
- Kafka event streaming
- Database connection pooling
- Optimized queries with Prisma

</td>
</tr>
<tr>
<td>

**🛠 Developer Experience**
- Type-safe with TypeScript
- Comprehensive API documentation
- 90%+ test coverage
- Hot-reload development

</td>
<td>

**📊 Monitoring & Observability**
- Structured logging
- Health check endpoints
- Performance metrics
- Error tracking

</td>
</tr>
</table>

## 🛠 Technology Stack

<p align="center">
  <img src="https://skillicons.dev/icons?i=typescript,nodejs,express,postgresql,redis,kafka,jest,docker" alt="Tech Stack" />
</p>

| Category | Technology | Version |
|----------|------------|---------|
| **Runtime** | Node.js | 18+ |
| **Language** | TypeScript | 5.3+ |
| **Framework** | Express.js | 4.18+ |
| **Database** | PostgreSQL | 16.3 |
| **ORM** | Prisma | 5.7+ |
| **Caching** | Redis | 7.0+ |
| **Message Queue** | Kafka | 3.0+ |
| **Authentication** | JWT | Latest |
| **Testing** | Jest | 29+ |
| **Documentation** | Swagger/OpenAPI | 3.0 |
| **Linting** | ESLint + Prettier | Latest |

---

## 🚀 Quick Start

**Get up and running in 5 minutes:**

```bash
# 1. Clone and install
git clone https://github.com/topcoder/identity-service-v6.git
cd identity-service-v6
npm install

# 2. Setup environment
cp .env.example .env
# Edit .env with your database credentials

# 3. Setup database
npm run prisma:generate
npm run prisma:migrate

# 4. Start development server
npm run dev
```

🎉 **That's it!** Your service is now running at `http://localhost:3000`

> **💡 Pro tip:** Use Docker for even faster setup - see [Docker Support](#-docker-support)

---

## 📋 Prerequisites

Before running the application, ensure you have the following installed:

- Node.js 18 or higher
- PostgreSQL 16.3
- Redis (optional, for caching)
- Kafka (optional, for event streaming)

## 🔧 Installation & Setup

### 1. Clone the repository

```bash
git clone <repository-url>
cd identity-service-v6
```

### 2. Install dependencies

```bash
npm install
```

### 3. Environment Configuration

Copy the example environment file and configure your settings:

```bash
cp .env.example .env
```

Edit `.env` with your configuration:

```env
# Database
DATABASE_URL="postgresql://username:password@localhost:5432/identity_service"

# JWT
JWT_SECRET="your-super-secret-jwt-key"
JWT_EXPIRES_IN="24h"

# Redis (optional)
REDIS_HOST="localhost"
REDIS_PORT=6379

# Kafka (optional)
KAFKA_BROKERS="localhost:9092"

# Server
PORT=3000
NODE_ENV="development"
```

### 4. Database Setup

#### Using Docker (Recommended)

```bash
# Start PostgreSQL with Docker
docker run --name postgres-identity \
  -e POSTGRES_USER=identity \
  -e POSTGRES_PASSWORD=password \
  -e POSTGRES_DB=identity_service \
  -p 5432:5432 \
  -d postgres:16.3
```

#### Manual Setup

1. Create a PostgreSQL database
2. Update the `DATABASE_URL` in your `.env` file

### 5. Database Migration

```bash
# Generate Prisma client
npm run prisma:generate

# Run database migrations
npm run prisma:migrate

# (Optional) Seed the database
npm run db:seed
```

## 🏃‍♂️ Running the Application

### Development Mode

```bash
npm run dev
```

The server will start on `http://localhost:3000` with hot-reload enabled.

### Production Mode

```bash
# Build the application
npm run build

# Start the production server
npm start
```

## 🧪 Testing

### Run all tests

```bash
npm test
```

### Run tests with coverage

```bash
npm run test:coverage
```

### Run tests in watch mode

```bash
npm run test:watch
```

## 📚 API Documentation

### 🌐 Interactive Documentation

When running in development mode, explore the full API with Swagger UI:

```
🔗 http://localhost:3000/api-docs
```

### 🔑 Authentication

All authenticated endpoints require a JWT token in the Authorization header:

```bash
Authorization: Bearer <your-jwt-token>
```

### 📋 Core Endpoints

<details>
<summary><b>🔐 Authentication Endpoints</b></summary>

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| `POST` | `/api/v1/auth/login` | User login | ❌ |
| `POST` | `/api/v1/auth/logout` | User logout | ✅ |
| `POST` | `/api/v1/auth/refresh` | Refresh access token | ✅ |

**Example Login Request:**
```bash
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "user@example.com",
    "password": "securepassword"
  }'
```

**Example Response:**
```json
{
  "success": true,
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "id": "123",
      "email": "user@example.com",
      "firstName": "John",
      "lastName": "Doe"
    }
  }
}
```
</details>

<details>
<summary><b>👥 User Management Endpoints</b></summary>

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| `GET` | `/api/v1/users` | List users (paginated) | ✅ |
| `POST` | `/api/v1/users` | Create new user | ✅ |
| `GET` | `/api/v1/users/:id` | Get user by ID | ✅ |
| `PUT` | `/api/v1/users/:id` | Update user | ✅ |
| `DELETE` | `/api/v1/users/:id` | Delete user | ✅ |

**Example Create User:**
```bash
curl -X POST http://localhost:3000/api/v1/users \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "newuser@example.com",
    "firstName": "Jane",
    "lastName": "Smith",
    "password": "securepassword"
  }'
```
</details>

<details>
<summary><b>🎭 Role Management Endpoints</b></summary>

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| `GET` | `/api/v1/roles` | List all roles | ✅ |
| `POST` | `/api/v1/roles` | Create new role | ✅ |
| `GET` | `/api/v1/roles/:id` | Get role by ID | ✅ |
| `PUT` | `/api/v1/roles/:id` | Update role | ✅ |
| `DELETE` | `/api/v1/roles/:id` | Delete role | ✅ |

**Example Create Role:**
```bash
curl -X POST http://localhost:3000/api/v1/roles \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "moderator",
    "description": "Community moderator role"
  }'
```
</details>

<details>
<summary><b>👥 Group Management Endpoints</b></summary>

| Method | Endpoint | Description | Auth Required |
|--------|----------|-------------|---------------|
| `GET` | `/api/v1/groups` | List all groups | ✅ |
| `POST` | `/api/v1/groups` | Create new group | ✅ |
| `GET` | `/api/v1/groups/:id` | Get group by ID | ✅ |
| `PUT` | `/api/v1/groups/:id` | Update group | ✅ |
| `DELETE` | `/api/v1/groups/:id` | Delete group | ✅ |
</details>

### 📊 Response Format

All API responses follow a consistent format:

```json
{
  "success": true,
  "data": { /* response data */ },
  "message": "Operation completed successfully",
  "meta": {
    "timestamp": "2024-01-01T00:00:00.000Z",
    "requestId": "uuid-string"
  }
}
```

**Error Response:**
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": [
      {
        "field": "email",
        "message": "Email is required"
      }
    ]
  },
  "meta": {
    "timestamp": "2024-01-01T00:00:00.000Z",
    "requestId": "uuid-string"
  }
}
```

## 🔍 Verification & Health Checks

### Health Check

```bash
curl http://localhost:3000/health
```

Expected response:
```json
{
  "success": true,
  "message": "Identity Service is healthy",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "version": "1.0.0"
}
```

### Database Connection

```bash
# Check database connection
npm run prisma:studio
```

### Run Linting

```bash
npm run lint
```

### Format Code

```bash
npm run format
```

## 🐳 Docker Support

### 🚀 One-Command Setup

Get the entire stack running with Docker Compose:

```bash
# Clone and start everything
git clone https://github.com/topcoder/identity-service-v6.git
cd identity-service-v6
docker-compose up -d
```

This starts:
- ✅ PostgreSQL database
- ✅ Redis cache
- ✅ Kafka message broker
- ✅ Identity Service API

### 📦 Individual Docker Commands

**Build the application image:**
```bash
docker build -t identity-service-v6 .
```

**Run with environment variables:**
```bash
docker run -d \
  --name identity-service \
  -p 3000:3000 \
  -e DATABASE_URL="postgresql://user:pass@host:5432/db" \
  -e JWT_SECRET="your-secret" \
  identity-service-v6
```

**View logs:**
```bash
docker logs -f identity-service
```

### 🐋 Docker Compose Configuration

<details>
<summary>View complete docker-compose.yml</summary>

```yaml
version: '3.8'

services:
  # PostgreSQL Database
  postgres:
    image: postgres:16.3
    environment:
      POSTGRES_USER: identity
      POSTGRES_PASSWORD: password
      POSTGRES_DB: identity_service
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U identity"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Redis Cache
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Identity Service API
  api:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - DATABASE_URL=postgresql://identity:password@postgres:5432/identity_service
      - REDIS_HOST=redis
      - JWT_SECRET=your-super-secret-jwt-key
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  postgres_data:
```
</details>

## 📊 Monitoring & Logging

- **Logs**: Application logs are written to `logs/` directory
- **Health**: Health check endpoint at `/health`
- **Metrics**: Performance metrics (if enabled)

## 🔧 Development Commands

```bash
# Development
npm run dev              # Start development server
npm run build           # Build for production
npm run start           # Start production server

# Database
npm run prisma:generate # Generate Prisma client
npm run prisma:migrate  # Run migrations
npm run prisma:studio   # Open Prisma Studio
npm run prisma:reset    # Reset database
npm run db:seed         # Seed database

# Testing
npm test                # Run tests
npm run test:watch      # Run tests in watch mode
npm run test:coverage   # Run tests with coverage

# Code Quality
npm run lint            # Run ESLint
npm run lint:fix        # Fix ESLint errors
npm run format          # Format code with Prettier
```

## 🚀 Deployment

### Environment Variables for Production

Make sure to set these environment variables in production:

```env
NODE_ENV=production
DATABASE_URL=<production-database-url>
JWT_SECRET=<secure-random-secret>
REDIS_HOST=<redis-host>
KAFKA_BROKERS=<kafka-brokers>
```

### PM2 Deployment

```bash
# Install PM2
npm install -g pm2

# Start with PM2
pm2 start dist/index.js --name identity-service

# Monitor
pm2 monit
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Ensure all tests pass
6. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify PostgreSQL is running
   - Check DATABASE_URL format
   - Ensure database exists

2. **Prisma Client Error**
   - Run `npm run prisma:generate`
   - Check schema.prisma syntax

3. **JWT Token Error**
   - Verify JWT_SECRET is set
   - Check token expiration

4. **Redis Connection Error**
   - Verify Redis is running
   - Check Redis host/port

### Getting Help

- Check the [Issues](../../issues) page for known problems
- Create a new issue for bugs or feature requests
- Contact the development team

## 📞 Support

For support and questions:
- Email: platform@topcoder.com
- Slack: #identity-service
- Documentation: [Wiki](../../wiki)
