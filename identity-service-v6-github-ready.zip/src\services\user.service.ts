/**
 * User Service for Identity Service
 * Business logic for user management operations
 */

import { PrismaClient, User, Prisma } from '@prisma/client';
import { hashPassword, comparePassword, generateCacheKey } from '../utils/helpers';
import { logBusiness, logError, logCache } from '../utils/logger';
import { CACHE_CONSTANTS } from '../utils/constants';

const prisma = new PrismaClient();

export class UserService {
  /**
   * Get user by ID with caching
   */
  static async getUserById(id: string): Promise<User | null> {
    try {
      const cacheKey = generateCacheKey('user', id);

      // Try to get from cache first
      // Note: Redis integration would go here

      const user = await prisma.user.findUnique({
        where: { id },
        include: {
          userRoles: {
            include: {
              role: true,
            },
          },
        },
      });

      if (user) {
        // Cache the result
        logCache('SET', cacheKey, false, CACHE_CONSTANTS.USER_CACHE_TTL);
      }

      return user;
    } catch (error) {
      logError(error as Error, { operation: 'getUserById', userId: id });
      throw error;
    }
  }

  /**
   * Get user by username
   */
  static async getUserByUsername(username: string): Promise<User | null> {
    try {
      return await prisma.user.findUnique({
        where: { username },
        include: {
          userRoles: {
            include: {
              role: true,
            },
          },
        },
      });
    } catch (error) {
      logError(error as Error, { operation: 'getUserByUsername', username });
      throw error;
    }
  }

  /**
   * Get user by email
   */
  static async getUserByEmail(email: string): Promise<User | null> {
    try {
      return await prisma.user.findUnique({
        where: { email },
        include: {
          userRoles: {
            include: {
              role: true,
            },
          },
        },
      });
    } catch (error) {
      logError(error as Error, { operation: 'getUserByEmail', email });
      throw error;
    }
  }

  /**
   * Create a new user
   */
  static async createUser(userData: {
    username: string;
    email: string;
    password: string;
    firstName?: string;
    lastName?: string;
  }): Promise<User> {
    try {
      const hashedPassword = await hashPassword(userData.password);

      const user = await prisma.user.create({
        data: {
          ...userData,
          password: hashedPassword,
        },
      });

      // Publish event
      // Note: Kafka integration would go here
      logBusiness('User created', 'user', user.id, undefined, {
        username: user.username,
        email: user.email,
      });

      // Clear relevant caches
      // Note: Redis cache clearing would go here

      return user;
    } catch (error) {
      logError(error as Error, { operation: 'createUser', userData: { ...userData, password: '[REDACTED]' } });
      throw error;
    }
  }

  /**
   * Update user
   */
  static async updateUser(id: string, updateData: Partial<{
    username: string;
    email: string;
    firstName: string;
    lastName: string;
    isActive: boolean;
  }>): Promise<User> {
    try {
      const user = await prisma.user.update({
        where: { id },
        data: {
          ...updateData,
          updatedAt: new Date(),
        },
      });

      // Publish event
      logBusiness('User updated', 'user', user.id, undefined, updateData);

      // Clear cache
      const cacheKey = generateCacheKey('user', id);
      logCache('DEL', cacheKey);

      return user;
    } catch (error) {
      logError(error as Error, { operation: 'updateUser', userId: id, updateData });
      throw error;
    }
  }

  /**
   * Delete user (soft delete)
   */
  static async deleteUser(id: string): Promise<void> {
    try {
      await prisma.user.update({
        where: { id },
        data: {
          isActive: false,
          updatedAt: new Date(),
        },
      });

      // Publish event
      logBusiness('User deleted', 'user', id);

      // Clear cache
      const cacheKey = generateCacheKey('user', id);
      logCache('DEL', cacheKey);
    } catch (error) {
      logError(error as Error, { operation: 'deleteUser', userId: id });
      throw error;
    }
  }

  /**
   * Verify user password
   */
  static async verifyPassword(userId: string, password: string): Promise<boolean> {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { password: true },
      });

      if (!user) {
        return false;
      }

      return await comparePassword(password, user.password);
    } catch (error) {
      logError(error as Error, { operation: 'verifyPassword', userId });
      throw error;
    }
  }

  /**
   * Update user password
   */
  static async updatePassword(userId: string, newPassword: string): Promise<void> {
    try {
      const hashedPassword = await hashPassword(newPassword);

      await prisma.user.update({
        where: { id: userId },
        data: {
          password: hashedPassword,
          updatedAt: new Date(),
        },
      });

      // Publish event
      logBusiness('User password updated', 'user', userId);

      // Clear cache
      const cacheKey = generateCacheKey('user', userId);
      logCache('DEL', cacheKey);
    } catch (error) {
      logError(error as Error, { operation: 'updatePassword', userId });
      throw error;
    }
  }

  /**
   * Update last login timestamp
   */
  static async updateLastLogin(userId: string): Promise<void> {
    try {
      await prisma.user.update({
        where: { id: userId },
        data: {
          lastLoginAt: new Date(),
        },
      });

      // Clear cache
      const cacheKey = generateCacheKey('user', userId);
      logCache('DEL', cacheKey);
    } catch (error) {
      logError(error as Error, { operation: 'updateLastLogin', userId });
      throw error;
    }
  }

  /**
   * Search users with pagination
   */
  static async searchUsers(params: {
    search?: string;
    isActive?: boolean;
    page: number;
    limit: number;
    sortBy: string;
    sortOrder: 'asc' | 'desc';
  }): Promise<{ users: User[]; total: number }> {
    try {
      const { search, isActive, page, limit, sortBy, sortOrder } = params;
      const offset = (page - 1) * limit;

      const where: Prisma.UserWhereInput = {};

      if (search) {
        where.OR = [
          { username: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
        ];
      }

      if (isActive !== undefined) {
        where.isActive = isActive;
      }

      const orderBy: Prisma.UserOrderByWithRelationInput = {};
      if (sortBy === 'username') {
        orderBy.username = sortOrder;
      } else if (sortBy === 'email') {
        orderBy.email = sortOrder;
      } else if (sortBy === 'updatedAt') {
        orderBy.updatedAt = sortOrder;
      } else {
        orderBy.createdAt = sortOrder;
      }

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          orderBy,
          skip: offset,
          take: limit,
          include: {
            userRoles: {
              include: {
                role: true,
              },
            },
          },
        }),
        prisma.user.count({ where }),
      ]);

      return { users, total };
    } catch (error) {
      logError(error as Error, { operation: 'searchUsers', params });
      throw error;
    }
  }
}

export default UserService;
