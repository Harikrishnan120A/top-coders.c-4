/**
 * Group Routes for Identity Service
 * RESTful API routes for group management with comprehensive validation
 */

import { Router } from 'express';
import {
  getGroups,
  getGroupById,
  createGroup,
  updateGroup,
  deleteGroup,
  getGroupMembers,
  addGroupMember,
  updateGroupMember,
  removeGroupMember,
  validateGetGroups,
  validateGroupId,
  validateCreateGroup,
  validateUpdateGroup,
  validateGroupMembers,
  validateAddGroupMember,
  validateUpdateGroupMember,
  validateRemoveGroupMember,
} from '../controllers/group.controller';
import { authenticate } from '../middleware/auth';

const router = Router();

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * @swagger
 * tags:
 *   - name: Groups
 *     description: Group management operations
 *   - name: Group Members
 *     description: Group membership management operations
 */

/**
 * Group CRUD Operations
 */

// GET /api/groups - Get paginated list of groups with search and filters
router.get('/', validateGetGroups, getGroups);

// GET /api/groups/:id - Get group by ID with members
router.get('/:id', validateGroupId, getGroupById);

// POST /api/groups - Create new group
router.post('/', validateCreateGroup, createGroup);

// PUT /api/groups/:id - Update group
router.put('/:id', validateUpdateGroup, updateGroup);

// DELETE /api/groups/:id - Soft delete group
router.delete('/:id', validateGroupId, deleteGroup);

/**
 * Group Member Management Operations
 */

// GET /api/groups/:id/members - Get paginated list of group members
router.get('/:id/members', validateGroupMembers, getGroupMembers);

// POST /api/groups/:id/members - Add member to group
router.post('/:id/members', validateAddGroupMember, addGroupMember);

// PUT /api/groups/:id/members/:memberId - Update group member
router.put('/:id/members/:memberId', validateUpdateGroupMember, updateGroupMember);

// DELETE /api/groups/:id/members/:memberId - Remove member from group
router.delete('/:id/members/:memberId', validateRemoveGroupMember, removeGroupMember);

export default router;
