/**
 * Authentication Routes for Identity Service
 * Handles registration, login, token management, password reset, etc.
 */

import { Router } from 'express';
import { body } from 'express-validator';
import { AuthController } from '../controllers/auth.controller';
import { authenticate } from '../middleware/auth';

const router = Router();

/**
 * @swagger
 * tags:
 *   name: Authentication
 *   description: User authentication endpoints
 */

/**
 * User Registration - Note: register method not yet implemented in AuthController
 */
// router.post('/register',
//   [
//     body('username')
//       .isLength({ min: 3, max: 50 })
//       .withMessage('Username must be between 3 and 50 characters')
//       .matches(/^[a-zA-Z0-9_-]+$/)
//       .withMessage('Username can only contain letters, numbers, underscores, and hyphens'),
//     body('email')
//       .isEmail()
//       .withMessage('Please provide a valid email address')
//       .normalizeEmail(),
//     body('password')
//       .isLength({ min: 8 })
//       .withMessage('Password must be at least 8 characters long')
//       .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
//       .withMessage('Password must contain lowercase, uppercase, number, and special character'),
//     body('firstName')
//       .isLength({ min: 1, max: 50 })
//       .withMessage('First name must be between 1 and 50 characters'),
//     body('lastName')
//       .isLength({ min: 1, max: 50 })
//       .withMessage('Last name must be between 1 and 50 characters'),
//   ],
//   AuthController.register,
// );

/**
 * User Login
 */
router.post('/login',
  [
    body('username')
      .notEmpty()
      .withMessage('Username is required'),
    body('password')
      .notEmpty()
      .withMessage('Password is required'),
  ],
  AuthController.login,
);

/**
 * Refresh Token
 */
router.post('/refresh',
  [
    body('refreshToken')
      .notEmpty()
      .withMessage('Refresh token is required'),
  ],
  AuthController.refreshToken,
);

/**
 * Logout
 */
router.post('/logout',
  authenticate,
  AuthController.logout,
);

/**
 * Logout from all devices - Note: logoutAll method not yet implemented
 */
// router.post('/logout-all',
//   authenticate,
//   AuthController.logoutAll,
// );

/**
 * Request Password Reset (maps to forgotPassword method)
 */
router.post('/forgot-password',
  [
    body('email')
      .isEmail()
      .withMessage('Please provide a valid email address')
      .normalizeEmail(),
  ],
  AuthController.forgotPassword,
);

/**
 * Reset Password
 */
router.post('/reset-password',
  [
    body('token')
      .notEmpty()
      .withMessage('Reset token is required'),
    body('password')
      .isLength({ min: 8 })
      .withMessage('Password must be at least 8 characters long')
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
      .withMessage('Password must contain lowercase, uppercase, number, and special character'),
  ],
  AuthController.resetPassword,
);

/**
 * Change Password (for authenticated users)
 */
router.post('/change-password',
  authenticate,
  [
    body('currentPassword')
      .notEmpty()
      .withMessage('Current password is required'),
    body('newPassword')
      .isLength({ min: 8 })
      .withMessage('New password must be at least 8 characters long')
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
      .withMessage('New password must contain lowercase, uppercase, number, and special character'),
  ],
  AuthController.changePassword,
);

/**
 * Verify Email - Note: method not yet implemented
 */
// router.get('/verify-email/:token',
//   AuthController.verifyEmail,
// );

/**
 * Resend Email Verification - Note: method not yet implemented
 */
// router.post('/resend-verification',
//   authenticate,
//   AuthController.resendVerification,
// );

/**
 * Get Current User Profile
 */
router.get('/me',
  authenticate,
  AuthController.getCurrentUser,
);

/**
 * Update Current User Profile - Note: method not yet implemented
 */
// router.put('/me',
//   authenticate,
//   [
//     body('firstName')
//       .optional()
//       .isLength({ min: 1, max: 50 })
//       .withMessage('First name must be between 1 and 50 characters'),
//     body('lastName')
//       .optional()
//       .isLength({ min: 1, max: 50 })
//       .withMessage('Last name must be between 1 and 50 characters'),
//     body('email')
//       .optional()
//       .isEmail()
//       .withMessage('Please provide a valid email address')
//       .normalizeEmail(),
//     body('phone')
//       .optional()
//       .isMobilePhone('any')
//       .withMessage('Please provide a valid phone number'),
//   ],
//   AuthController.updateProfile,
// );

/**
 * Validate Token - Note: method not yet implemented
 */
// router.post('/validate-token',
//   optionalAuth,
//   AuthController.validateToken,
// );

export default router;
