/**
 * Group Controller for Identity Service
 * Handles all group-related HTTP requests with comprehensive validation,
 * error handling, membership management, and API documentation
 */

import { Response } from 'express';
import { validationResult, body, param, query } from 'express-validator';
import { PrismaClient, Prisma } from '@prisma/client';

import {
  AuthenticatedRequest,
  CreateGroupInput,
  UpdateGroupInput,
  GroupQuery,
  CreateGroupMemberInput,
  UpdateGroupMemberInput,
} from '../types';
import {
  sendSuccess,
  sendError,
  sendValidationError,
  parsePaginationQuery,
  getPaginationMeta,
  getOffset,
  getClientIp,
  getUserAgent,
} from '../utils/helpers';
import {
  HTTP_STATUS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
} from '../utils/constants';
import {
  logBusiness,
  logError,
  logValidation,
} from '../utils/logger';

const prisma = new PrismaClient();

// Helper function to handle validation errors consistently
const handleValidationErrors = (req: AuthenticatedRequest, res: Response): boolean => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const userId = req.user?.id || 'unknown';
    logValidation('Invalid request data', errors.array(), 'Validation failed', userId);

    // Convert express-validator errors to our format
    const validationErrors = errors.array().map(err => ({
      field: ('param' in err && typeof err.param === 'string') ? err.param : 'unknown',
      message: typeof err.msg === 'string' ? err.msg : 'Invalid value',
    }));

    sendValidationError(res, validationErrors);
    return true;
  }
  return false;
};

// Helper function to log business events with proper signature
const logBusinessEvent = (action: string, details: any, userId?: string): void => {
  const entityType = 'group';
  const entityId = details.groupId || details.id || 'unknown';
  logBusiness(action, entityType, entityId, userId, details);
};

// Helper function to parse boolean query parameters
const parseBooleanQuery = (value: string | undefined): boolean | undefined => {
  if (value === undefined) return undefined;
  return value === 'true' || value === '1';
};

/**
 * @swagger
 * components:
 *   schemas:
 *     Group:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           description: Unique identifier for the group
 *         name:
 *           type: string
 *           description: Name of the group
 *         description:
 *           type: string
 *           description: Description of the group
 *         isPrivate:
 *           type: boolean
 *           description: Whether the group is private
 *         isActive:
 *           type: boolean
 *           description: Whether the group is active
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Creation timestamp
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           description: Last update timestamp
 *         createdBy:
 *           type: string
 *           format: uuid
 *           description: ID of the user who created the group
 *         _count:
 *           type: object
 *           properties:
 *             groupMembers:
 *               type: integer
 *               description: Number of members in the group
 *     GroupMember:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           description: Unique identifier for the membership
 *         groupId:
 *           type: string
 *           format: uuid
 *           description: ID of the group
 *         userId:
 *           type: string
 *           format: uuid
 *           description: ID of the user
 *         membershipTypeId:
 *           type: string
 *           format: uuid
 *           description: ID of the membership type
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Creation timestamp
 *         user:
 *           $ref: '#/components/schemas/User'
 *     CreateGroupRequest:
 *       type: object
 *       required:
 *         - name
 *       properties:
 *         name:
 *           type: string
 *           minLength: 1
 *           maxLength: 100
 *           description: Name of the group
 *         description:
 *           type: string
 *           maxLength: 500
 *           description: Description of the group
 *         isPrivate:
 *           type: boolean
 *           default: false
 *           description: Whether the group is private
 *     UpdateGroupRequest:
 *       type: object
 *       properties:
 *         name:
 *           type: string
 *           minLength: 1
 *           maxLength: 100
 *           description: Name of the group
 *         description:
 *           type: string
 *           maxLength: 500
 *           description: Description of the group
 *         isPrivate:
 *           type: boolean
 *           description: Whether the group is private
 *         isActive:
 *           type: boolean
 *           description: Whether the group is active
 *     CreateGroupMemberRequest:
 *       type: object
 *       required:
 *         - userId
 *       properties:
 *         userId:
 *           type: string
 *           format: uuid
 *           description: ID of the user to add to the group
 *         membershipTypeId:
 *           type: string
 *           format: uuid
 *           description: ID of the membership type
 *     UpdateGroupMemberRequest:
 *       type: object
 *       properties:
 *         membershipTypeId:
 *           type: string
 *           format: uuid
 *           description: ID of the membership type
 */

/**
 * @swagger
 * /api/groups:
 *   get:
 *     tags: [Groups]
 *     summary: Get paginated list of groups
 *     description: Retrieves a paginated list of groups with optional filtering and search
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: Number of groups per page
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Search term for group name or description
 *       - in: query
 *         name: isPrivate
 *         schema:
 *           type: boolean
 *         description: Filter by privacy status
 *       - in: query
 *         name: isActive
 *         schema:
 *           type: boolean
 *         description: Filter by active status
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [name, createdAt, updatedAt]
 *           default: createdAt
 *         description: Field to sort by
 *       - in: query
 *         name: sortOrder
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: desc
 *         description: Sort order
 *     responses:
 *       200:
 *         description: Groups retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Group'
 *                 meta:
 *                   $ref: '#/components/schemas/PaginationMeta'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const getGroups = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    const query: GroupQuery = req.query;
    const { page, limit, sortBy, sortOrder } = parsePaginationQuery(query);
    const offset = getOffset(page, limit);

    // Build where clause
    const where: Prisma.GroupWhereInput = {
      isActive: true, // Only show active groups by default
    };

    // Add search filter
    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { description: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    // Add privacy filter
    if (query.isPrivate !== undefined) {
      where.isPrivate = parseBooleanQuery(query.isPrivate);
    }

    // Add active filter (override default if specified)
    if (query.isActive !== undefined) {
      where.isActive = parseBooleanQuery(query.isActive);
    }

    // Build order by clause
    const orderBy: Prisma.GroupOrderByWithRelationInput = {};
    if (sortBy === 'name') {
      orderBy.name = sortOrder as 'asc' | 'desc';
    } else if (sortBy === 'updatedAt') {
      orderBy.updatedAt = sortOrder as 'asc' | 'desc';
    } else {
      orderBy.createdAt = sortOrder as 'asc' | 'desc';
    }

    // Execute queries
    const [groups, total] = await Promise.all([
      prisma.group.findMany({
        where,
        orderBy,
        skip: offset,
        take: limit,
        include: {
          _count: {
            select: { groupMembers: true },
          },
        },
      }),
      prisma.group.count({ where }),
    ]);

    const meta = getPaginationMeta(page, limit, total);

    logBusinessEvent('Groups retrieved', {
      groupId: 'multiple',
      count: groups.length,
      total,
      page,
      limit,
      search: query.search,
      filters: { isPrivate: query.isPrivate, isActive: query.isActive },
    }, req.user?.id);

    sendSuccess(res, groups, 'Groups retrieved successfully', HTTP_STATUS.OK, meta);
  } catch (error) {
    logError(error as Error, { operation: 'getGroups' }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups/{id}:
 *   get:
 *     tags: [Groups]
 *     summary: Get group by ID
 *     description: Retrieves a specific group by its ID with member count
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Group ID
 *     responses:
 *       200:
 *         description: Group retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/Group'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const getGroupById = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const { id } = req.params;

    const group = await prisma.group.findUnique({
      where: { id },
      include: {
        groupMembers: {
          include: {
            user: {
              select: {
                id: true,
                username: true,
                email: true,
                firstName: true,
                lastName: true,
                isActive: true,
              },
            },
          },
        },
        _count: {
          select: { groupMembers: true },
        },
      },
    });

    if (!group) {
      logBusinessEvent('Group not found', { groupId: id }, req.user?.id);
      sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.GROUP_NOT_FOUND);
      return;
    }

    logBusinessEvent('Group retrieved', { groupId: id, memberCount: group.groupMembers.length }, req.user?.id);
    sendSuccess(res, group, 'Group retrieved successfully');
  } catch (error) {
    logError(error as Error, { operation: 'getGroupById', groupId: req.params.id }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups:
 *   post:
 *     tags: [Groups]
 *     summary: Create a new group
 *     description: Creates a new group with the authenticated user as the creator
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateGroupRequest'
 *     responses:
 *       201:
 *         description: Group created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/Group'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       409:
 *         $ref: '#/components/responses/Conflict'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const createGroup = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const createData: CreateGroupInput = req.body;
    const userId = req.user!.id;

    // Check if group name already exists
    const existingGroup = await prisma.group.findFirst({
      where: { name: createData.name },
    });

    if (existingGroup) {
      logBusinessEvent('Group creation failed - name already exists', { name: createData.name }, userId);
      sendError(res, HTTP_STATUS.CONFLICT, ERROR_MESSAGES.GROUP_NAME_EXISTS);
      return;
    }

    // Create group
    const group = await prisma.group.create({
      data: {
        ...createData,
        isActive: true,
      },
      include: {
        _count: {
          select: { groupMembers: true },
        },
      },
    });

    logBusinessEvent('Group created', {
      groupId: group.id,
      name: group.name,
      isPrivate: group.isPrivate,
      clientIp: getClientIp(req),
      userAgent: getUserAgent(req),
    }, userId);

    sendSuccess(res, group, SUCCESS_MESSAGES.GROUP_CREATED, HTTP_STATUS.CREATED);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2002') {
        logBusinessEvent('Group creation failed - unique constraint violation', { name: req.body.name }, req.user?.id);
        sendError(res, HTTP_STATUS.CONFLICT, ERROR_MESSAGES.GROUP_NAME_EXISTS);
        return;
      }
    }

    logError(error as Error, { operation: 'createGroup', data: req.body }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups/{id}:
 *   put:
 *     tags: [Groups]
 *     summary: Update group
 *     description: Updates an existing group
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Group ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateGroupRequest'
 *     responses:
 *       200:
 *         description: Group updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/Group'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       409:
 *         $ref: '#/components/responses/Conflict'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const updateGroup = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const { id } = req.params;
    const updateData: UpdateGroupInput = req.body;
    const userId = req.user!.id;

    // Check if group exists
    const existingGroup = await prisma.group.findUnique({
      where: { id },
    });

    if (!existingGroup) {
      logBusinessEvent('Group update failed - not found', { groupId: id }, userId);
      sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.GROUP_NOT_FOUND);
      return;
    }

    // Check if new name conflicts with existing group (if name is being updated)
    if (updateData.name && updateData.name !== existingGroup.name) {
      const nameConflict = await prisma.group.findFirst({
        where: {
          name: updateData.name,
          id: { not: id },
        },
      });

      if (nameConflict) {
        logBusinessEvent('Group update failed - name already exists', { groupId: id, name: updateData.name }, userId);
        sendError(res, HTTP_STATUS.CONFLICT, ERROR_MESSAGES.GROUP_NAME_EXISTS);
        return;
      }
    }

    // Update group
    const updatedGroup = await prisma.group.update({
      where: { id },
      data: {
        ...updateData,
        updatedAt: new Date(),
      },
      include: {
        _count: {
          select: { groupMembers: true },
        },
      },
    });

    logBusinessEvent('Group updated', {
      groupId: id,
      changes: updateData,
      clientIp: getClientIp(req),
      userAgent: getUserAgent(req),
    }, userId);

    sendSuccess(res, updatedGroup, SUCCESS_MESSAGES.GROUP_UPDATED);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2002') {
        logBusinessEvent('Group update failed - unique constraint violation', { groupId: req.params.id, name: req.body.name }, req.user?.id);
        sendError(res, HTTP_STATUS.CONFLICT, ERROR_MESSAGES.GROUP_NAME_EXISTS);
        return;
      }
    }

    logError(error as Error, { operation: 'updateGroup', groupId: req.params.id, data: req.body }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups/{id}:
 *   delete:
 *     tags: [Groups]
 *     summary: Delete group
 *     description: Soft deletes a group by setting isActive to false
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Group ID
 *     responses:
 *       200:
 *         description: Group deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Group deleted successfully"
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const deleteGroup = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const { id } = req.params;
    const userId = req.user!.id;

    // Check if group exists and get member count
    const existingGroup = await prisma.group.findUnique({
      where: { id },
      include: {
        _count: {
          select: { groupMembers: true },
        },
      },
    });

    if (!existingGroup) {
      logBusinessEvent('Group deletion failed - not found', { groupId: id }, userId);
      sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.GROUP_NOT_FOUND);
      return;
    }

    // Soft delete the group
    await prisma.group.update({
      where: { id },
      data: {
        isActive: false,
        updatedAt: new Date(),
      },
    });

    logBusinessEvent('Group deleted', {
      groupId: id,
      name: existingGroup.name,
      memberCount: existingGroup._count.groupMembers,
      clientIp: getClientIp(req),
      userAgent: getUserAgent(req),
    }, userId);

    sendSuccess(res, null, SUCCESS_MESSAGES.GROUP_DELETED);
  } catch (error) {
    logError(error as Error, { operation: 'deleteGroup', groupId: req.params.id }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups/{id}/members:
 *   get:
 *     tags: [Group Members]
 *     summary: Get group members
 *     description: Retrieves a paginated list of group members
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Group ID
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *         description: Page number
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *         description: Number of members per page
 *     responses:
 *       200:
 *         description: Group members retrieved successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/GroupMember'
 *                 meta:
 *                   $ref: '#/components/schemas/PaginationMeta'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const getGroupMembers = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const { id } = req.params;
    const query = req.query;
    const { page, limit } = parsePaginationQuery(query);
    const offset = getOffset(page, limit);

    // Check if group exists
    const group = await prisma.group.findUnique({
      where: { id },
    });

    if (!group) {
      logBusinessEvent('Group not found', { groupId: id }, req.user?.id);
      sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.GROUP_NOT_FOUND);
      return;
    }

    // Get group members
    const [members, total] = await Promise.all([
      prisma.groupMember.findMany({
        where: { groupId: id },
        orderBy: { joinedAt: 'desc' },
        skip: offset,
        take: limit,
        include: {
          user: {
            select: {
              id: true,
              username: true,
              email: true,
              firstName: true,
              lastName: true,
              isActive: true,
              createdAt: true,
            },
          },
        },
      }),
      prisma.groupMember.count({
        where: { groupId: id },
      }),
    ]);

    const meta = getPaginationMeta(page, limit, total);

    logBusinessEvent('Group members retrieved', {
      groupId: id,
      count: members.length,
      total,
      page,
      limit,
    }, req.user?.id);

    sendSuccess(res, members, 'Group members retrieved successfully', HTTP_STATUS.OK, meta);
  } catch (error) {
    logError(error as Error, { operation: 'getGroupMembers', groupId: req.params.id }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups/{id}/members:
 *   post:
 *     tags: [Group Members]
 *     summary: Add member to group
 *     description: Adds a new member to the specified group
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Group ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateGroupMemberRequest'
 *     responses:
 *       201:
 *         description: Member added to group successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GroupMember'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       409:
 *         $ref: '#/components/responses/Conflict'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const addGroupMember = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const { id } = req.params;
    const memberData: CreateGroupMemberInput = req.body;
    const userId = req.user!.id;

    // Check if group exists
    const group = await prisma.group.findUnique({
      where: { id },
    });

    if (!group) {
      logBusinessEvent('Group not found', { groupId: id }, userId);
      sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.GROUP_NOT_FOUND);
      return;
    }

    // Check if user exists and is active
    const user = await prisma.user.findUnique({
      where: { id: memberData.userId },
    });

    if (!user) {
      logBusinessEvent('User not found for group membership', { userId: memberData.userId, groupId: id }, userId);
      sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.USER_NOT_FOUND);
      return;
    }

    if (!user.isActive) {
      logBusinessEvent('Cannot add inactive user to group', { userId: memberData.userId, groupId: id }, userId);
      sendError(res, HTTP_STATUS.BAD_REQUEST, 'Cannot add inactive user to group');
      return;
    }

    // Validate membership type if provided
    if (memberData.membershipTypeId) {
      const membershipType = await prisma.membershipType.findUnique({
        where: { id: memberData.membershipTypeId },
      });

      if (!membershipType) {
        logBusinessEvent('Invalid membership type', { membershipTypeId: memberData.membershipTypeId, groupId: id }, userId);
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Invalid membership type');
        return;
      }
    }

    // Check if user is already a member
    const existingMembership = await prisma.groupMember.findFirst({
      where: {
        groupId: id,
        userId: memberData.userId,
      },
    });

    if (existingMembership) {
      logBusinessEvent('User already a group member', { userId: memberData.userId, groupId: id }, userId);
      sendError(res, HTTP_STATUS.CONFLICT, 'User is already a member of this group');
      return;
    }

    // Add member to group
    const groupMember = await prisma.groupMember.create({
      data: {
        groupId: id,
        userId: memberData.userId,
        membershipTypeId: memberData.membershipTypeId,
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            email: true,
            firstName: true,
            lastName: true,
            isActive: true,
          },
        },
      },
    });

    logBusinessEvent('Group member added', {
      groupId: id,
      userId: memberData.userId,
      membershipTypeId: memberData.membershipTypeId,
      clientIp: getClientIp(req),
      userAgent: getUserAgent(req),
    }, userId);

    sendSuccess(res, groupMember, 'Group member added successfully', HTTP_STATUS.CREATED);
  } catch (error) {
    logError(error as Error, { operation: 'addGroupMember', groupId: req.params.id, data: req.body }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups/{id}/members/{memberId}:
 *   put:
 *     tags: [Group Members]
 *     summary: Update group member
 *     description: Updates a group member's information
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Group ID
 *       - in: path
 *         name: memberId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Member ID
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/UpdateGroupMemberRequest'
 *     responses:
 *       200:
 *         description: Group member updated successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 data:
 *                   $ref: '#/components/schemas/GroupMember'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const updateGroupMember = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const { id, memberId } = req.params;
    const updateData: UpdateGroupMemberInput = req.body;
    const userId = req.user!.id;

    // Check if membership exists
    const existingMembership = await prisma.groupMember.findFirst({
      where: {
        id: memberId,
        groupId: id,
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            email: true,
            firstName: true,
            lastName: true,
          },
        },
      },
    });

    if (!existingMembership) {
      logBusinessEvent('Group membership not found', { groupId: id, memberId }, userId);
      sendError(res, HTTP_STATUS.NOT_FOUND, 'Group membership not found');
      return;
    }

    // Validate membership type if provided
    if (updateData.membershipTypeId) {
      const membershipType = await prisma.membershipType.findUnique({
        where: { id: updateData.membershipTypeId },
      });

      if (!membershipType) {
        logBusinessEvent('Invalid membership type', { membershipTypeId: updateData.membershipTypeId, groupId: id }, userId);
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Invalid membership type');
        return;
      }
    }

    // Update membership
    const updatedMembership = await prisma.groupMember.update({
      where: { id: memberId },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            username: true,
            email: true,
            firstName: true,
            lastName: true,
            isActive: true,
          },
        },
      },
    });

    logBusinessEvent('Group member updated', {
      groupId: id,
      memberId,
      userId: existingMembership.user.id,
      changes: updateData,
      clientIp: getClientIp(req),
      userAgent: getUserAgent(req),
    }, userId);

    sendSuccess(res, updatedMembership, 'Group member updated successfully');
  } catch (error) {
    logError(error as Error, { operation: 'updateGroupMember', groupId: req.params.id, memberId: req.params.memberId, data: req.body }, req.user?.id);
    sendError(res);
  }
};

/**
 * @swagger
 * /api/groups/{id}/members/{memberId}:
 *   delete:
 *     tags: [Group Members]
 *     summary: Remove member from group
 *     description: Removes a member from the specified group
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Group ID
 *       - in: path
 *         name: memberId
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: Member ID
 *     responses:
 *       200:
 *         description: Member removed from group successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: "Member removed from group successfully"
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       401:
 *         $ref: '#/components/responses/Unauthorized'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/InternalServerError'
 */
export const removeGroupMember = async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  try {
    if (handleValidationErrors(req, res)) return;

    const { id, memberId } = req.params;
    const userId = req.user!.id;

    // Check if membership exists
    const existingMembership = await prisma.groupMember.findFirst({
      where: {
        id: memberId,
        groupId: id,
      },
      include: {
        user: {
          select: {
            id: true,
            username: true,
          },
        },
      },
    });

    if (!existingMembership) {
      logBusinessEvent('Group membership not found', { groupId: id, memberId }, userId);
      sendError(res, HTTP_STATUS.NOT_FOUND, 'Group membership not found');
      return;
    }

    // Remove membership
    await prisma.groupMember.delete({
      where: { id: memberId },
    });

    logBusinessEvent('Group member removed', {
      groupId: id,
      memberId,
      userId: existingMembership.user.id,
      clientIp: getClientIp(req),
      userAgent: getUserAgent(req),
    }, userId);

    sendSuccess(res, null, 'Group member removed successfully');
  } catch (error) {
    logError(error as Error, { operation: 'removeGroupMember', groupId: req.params.id, memberId: req.params.memberId }, req.user?.id);
    sendError(res);
  }
};

// Validation rules
export const validateGetGroups = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('search').optional().isLength({ max: 100 }).withMessage('Search term must be 100 characters or less'),
  query('isPrivate').optional().isBoolean().withMessage('isPrivate must be a boolean'),
  query('isActive').optional().isBoolean().withMessage('isActive must be a boolean'),
  query('sortBy').optional().isIn(['name', 'createdAt', 'updatedAt']).withMessage('Invalid sortBy field'),
  query('sortOrder').optional().isIn(['asc', 'desc']).withMessage('Invalid sortOrder'),
];

export const validateGroupId = [
  param('id').isUUID().withMessage('Invalid UUID format'),
];

export const validateCreateGroup = [
  body('name')
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Name must be between 1 and 100 characters'),
  body('description')
    .optional()
    .isLength({ max: 500 })
    .withMessage('Description must be 500 characters or less'),
  body('isPrivate')
    .optional()
    .isBoolean()
    .withMessage('isPrivate must be a boolean'),
];

export const validateUpdateGroup = [
  param('id').isUUID().withMessage('Invalid UUID format'),
  body('name')
    .optional()
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('Name must be between 1 and 100 characters'),
  body('description')
    .optional()
    .isLength({ max: 500 })
    .withMessage('Description must be 500 characters or less'),
  body('isPrivate')
    .optional()
    .isBoolean()
    .withMessage('isPrivate must be a boolean'),
  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean'),
];

export const validateGroupMembers = [
  param('id').isUUID().withMessage('Invalid UUID format'),
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
];

export const validateAddGroupMember = [
  param('id').isUUID().withMessage('Invalid UUID format'),
  body('userId').isUUID().withMessage('userId must be a valid UUID'),
  body('membershipTypeId').optional().isUUID().withMessage('membershipTypeId must be a valid UUID'),
];

export const validateUpdateGroupMember = [
  param('id').isUUID().withMessage('Invalid UUID format'),
  param('memberId').isUUID().withMessage('memberId must be a valid UUID'),
  body('membershipTypeId').optional().isUUID().withMessage('membershipTypeId must be a valid UUID'),
];

export const validateRemoveGroupMember = [
  param('id').isUUID().withMessage('Invalid UUID format'),
  param('memberId').isUUID().withMessage('memberId must be a valid UUID'),
];
