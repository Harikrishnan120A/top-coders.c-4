/**
 * Role routes for Identity Service
 */

import { Router } from 'express';
import {
  RoleController,
  validateCreateRole,
  validateUpdateRole,
  validateRoleQuery,
} from '../controllers/role.controller';
import { authenticate } from '../middleware/auth';

const router = Router();

// Apply authentication middleware to all routes
router.use(authenticate);

/**
 * Role management routes
 */
router.get('/', validateRoleQuery, RoleController.getRoles);
router.get('/:id', RoleController.getRoleById);
router.post('/', validateCreateRole, RoleController.createRole);
router.put('/:id', validateUpdateRole, RoleController.updateRole);
router.delete('/:id', RoleController.deleteRole);

/**
 * Role users management routes
 */
router.get('/:id/users', RoleController.getRoleUsers);

export default router;
