/**
 * Constants file for Identity Service
 * This file contains all constants used throughout the application
 * to replace hardcoded values and magic numbers
 */

// HTTP Status Codes
export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  INTERNAL_SERVER_ERROR: 500,
} as const;

// Application Constants
export const APP_CONSTANTS = {
  DEFAULT_TARGET_ID: '1',
  DEFAULT_REDIRECT_URL: 'https://www.topcoder.com',
  RANDOM_STRING_LENGTH: 12,
  DEFAULT_SUBJECT_TYPE: 1,
  AUTH0_PREFIX: 'auth0|',
  DEFAULT_PAGE_SIZE: 20,
  MAX_PAGE_SIZE: 100,
} as const;

// Database Constants
export const DB_CONSTANTS = {
  DEFAULT_TARGET_ID: 1,
  ROLE_TYPE_USER: 1,
  ROLE_TYPE_ADMIN: 2,
  MEMBERSHIP_TYPE_MEMBER: 1,
  MEMBERSHIP_TYPE_ADMIN: 2,
} as const;

// Cache Constants
export const CACHE_CONSTANTS = {
  DEFAULT_TTL: 3600, // 1 hour
  USER_CACHE_TTL: 1800, // 30 minutes
  ROLE_CACHE_TTL: 7200, // 2 hours
  GROUP_CACHE_TTL: 3600, // 1 hour
} as const;

// Validation Constants
export const VALIDATION_CONSTANTS = {
  MIN_PASSWORD_LENGTH: 8,
  MAX_PASSWORD_LENGTH: 128,
  MIN_USERNAME_LENGTH: 3,
  MAX_USERNAME_LENGTH: 50,
  MAX_EMAIL_LENGTH: 255,
  MAX_NAME_LENGTH: 100,
  MIN_ROLE_NAME_LENGTH: 2,
  MAX_ROLE_NAME_LENGTH: 50,
  MIN_GROUP_NAME_LENGTH: 2,
  MAX_GROUP_NAME_LENGTH: 100,
} as const;

// JWT Constants
export const JWT_CONSTANTS = {
  DEFAULT_EXPIRY: '24h',
  REFRESH_TOKEN_EXPIRY: '7d',
  ISSUER: 'topcoder-identity-service',
} as const;

// Error Messages
export const ERROR_MESSAGES = {
  UNAUTHORIZED: 'Unauthorized access',
  FORBIDDEN: 'Forbidden access',
  NOT_FOUND: 'Resource not found',
  BAD_REQUEST: 'Bad request',
  INTERNAL_ERROR: 'Internal server error',
  VALIDATION_ERROR: 'Validation error',
  DUPLICATE_ROLE_NAME: 'Role name already exists',
  ROLE_NAME_EXISTS: 'Role name already exists',
  GROUP_NAME_EXISTS: 'Group name already exists',
  INVALID_CREDENTIALS: 'Invalid credentials',
  USER_NOT_FOUND: 'User not found',
  ROLE_NOT_FOUND: 'Role not found',
  GROUP_NOT_FOUND: 'Group not found',
  INVALID_TOKEN: 'Invalid token',
  TOKEN_EXPIRED: 'Token expired',
  MEMBERSHIP_NOT_FOUND: 'Membership not found',
  INVALID_MEMBERSHIP_TYPE: 'Invalid membership type',
} as const;

// Success Messages
export const SUCCESS_MESSAGES = {
  USER_CREATED: 'User created successfully',
  USER_UPDATED: 'User updated successfully',
  USER_DELETED: 'User deleted successfully',
  ROLE_CREATED: 'Role created successfully',
  ROLE_UPDATED: 'Role updated successfully',
  ROLE_DELETED: 'Role deleted successfully',
  GROUP_CREATED: 'Group created successfully',
  GROUP_UPDATED: 'Group updated successfully',
  GROUP_DELETED: 'Group deleted successfully',
  LOGIN_SUCCESS: 'Login successful',
  LOGOUT_SUCCESS: 'Logout successful',
} as const;

// Regex Patterns
export const REGEX_PATTERNS = {
  EMAIL: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  USERNAME: /^[a-zA-Z0-9_-]+$/,
  PASSWORD: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/,
  UUID: /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
} as const;

// Event Types for Kafka
export const EVENT_TYPES = {
  USER_CREATED: 'user.created',
  USER_UPDATED: 'user.updated',
  USER_DELETED: 'user.deleted',
  ROLE_CREATED: 'role.created',
  ROLE_UPDATED: 'role.updated',
  ROLE_DELETED: 'role.deleted',
  GROUP_CREATED: 'group.created',
  GROUP_UPDATED: 'group.updated',
  GROUP_DELETED: 'group.deleted',
  USER_LOGIN: 'user.login',
  USER_LOGOUT: 'user.logout',
} as const;

// Rate Limiting
export const RATE_LIMIT = {
  WINDOW_MS: 15 * 60 * 1000, // 15 minutes
  MAX_REQUESTS: 100, // per window
  LOGIN_MAX_REQUESTS: 5, // login attempts per window
  SKIP_SUCCESSFUL_REQUESTS: true,
} as const;

// Pagination
export const PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: 20,
  MAX_LIMIT: 100,
} as const;

// File paths and extensions
export const FILE_CONSTANTS = {
  LOG_DIR: './logs',
  UPLOAD_DIR: './uploads',
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/gif'],
} as const;

export type HttpStatus = typeof HTTP_STATUS[keyof typeof HTTP_STATUS];
export type AppConstant = typeof APP_CONSTANTS[keyof typeof APP_CONSTANTS];
export type DbConstant = typeof DB_CONSTANTS[keyof typeof DB_CONSTANTS];
export type CacheConstant = typeof CACHE_CONSTANTS[keyof typeof CACHE_CONSTANTS];
export type ValidationConstant = typeof VALIDATION_CONSTANTS[keyof typeof VALIDATION_CONSTANTS];
export type JwtConstant = typeof JWT_CONSTANTS[keyof typeof JWT_CONSTANTS];
export type ErrorMessage = typeof ERROR_MESSAGES[keyof typeof ERROR_MESSAGES];
export type SuccessMessage = typeof SUCCESS_MESSAGES[keyof typeof SUCCESS_MESSAGES];
export type EventType = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];
