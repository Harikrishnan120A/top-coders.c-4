/**
 * Role Service for Identity Service
 * Business logic for role management operations
 */

import { PrismaClient, Role, Prisma } from '@prisma/client';
import { generateCacheKey } from '../utils/helpers';
import { logBusiness, logError, logCache } from '../utils/logger';
import { CACHE_CONSTANTS } from '../utils/constants';

const prisma = new PrismaClient();

export class RoleService {
  /**
   * Get role by ID with caching
   */
  static async getRoleById(id: string): Promise<Role | null> {
    try {
      const cacheKey = generateCacheKey('role', id);

      // Try to get from cache first
      // Note: Redis integration would go here

      const role = await prisma.role.findUnique({
        where: { id },
        include: {
          userRoles: {
            include: {
              user: {
                select: {
                  id: true,
                  username: true,
                  email: true,
                  firstName: true,
                  lastName: true,
                  isActive: true,
                },
              },
            },
          },
        },
      });

      if (role) {
        // Cache the result
        logCache('SET', cacheKey, false, CACHE_CONSTANTS.ROLE_CACHE_TTL);
      }

      return role;
    } catch (error) {
      logError(error as Error, { operation: 'getRoleById', roleId: id });
      throw error;
    }
  }

  /**
   * Get role by name
   */
  static async getRoleByName(name: string): Promise<Role | null> {
    try {
      return await prisma.role.findUnique({
        where: { name },
      });
    } catch (error) {
      logError(error as Error, { operation: 'getRoleByName', name });
      throw error;
    }
  }

  /**
   * Create a new role
   */
  static async createRole(roleData: {
    name: string;
    description?: string;
  }): Promise<Role> {
    try {
      const role = await prisma.role.create({
        data: {
          ...roleData,
          isActive: true,
        },
      });

      // Publish event
      logBusiness('Role created', 'role', role.id, undefined, {
        name: role.name,
        description: role.description,
      });

      // Clear relevant caches
      // Note: Redis cache clearing would go here

      return role;
    } catch (error) {
      logError(error as Error, { operation: 'createRole', roleData });
      throw error;
    }
  }

  /**
   * Update role
   */
  static async updateRole(id: string, updateData: Partial<{
    name: string;
    description: string;
    isActive: boolean;
  }>): Promise<Role> {
    try {
      const role = await prisma.role.update({
        where: { id },
        data: {
          ...updateData,
          updatedAt: new Date(),
        },
      });

      // Publish event
      logBusiness('Role updated', 'role', role.id, undefined, updateData);

      // Clear cache
      const cacheKey = generateCacheKey('role', id);
      logCache('DEL', cacheKey);

      return role;
    } catch (error) {
      logError(error as Error, { operation: 'updateRole', roleId: id, updateData });
      throw error;
    }
  }

  /**
   * Delete role (soft delete)
   */
  static async deleteRole(id: string): Promise<void> {
    try {
      await prisma.role.update({
        where: { id },
        data: {
          isActive: false,
          updatedAt: new Date(),
        },
      });

      // Publish event
      logBusiness('Role deleted', 'role', id);

      // Clear cache
      const cacheKey = generateCacheKey('role', id);
      logCache('DEL', cacheKey);
    } catch (error) {
      logError(error as Error, { operation: 'deleteRole', roleId: id });
      throw error;
    }
  }

  /**
   * Search roles with pagination
   */
  static async searchRoles(params: {
    search?: string;
    isActive?: boolean;
    page: number;
    limit: number;
    sortBy: string;
    sortOrder: 'asc' | 'desc';
  }): Promise<{ roles: Role[]; total: number }> {
    try {
      const { search, isActive, page, limit, sortBy, sortOrder } = params;
      const offset = (page - 1) * limit;

      const where: Prisma.RoleWhereInput = {};

      if (search) {
        where.OR = [
          { name: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
        ];
      }

      if (isActive !== undefined) {
        where.isActive = isActive;
      }

      const orderBy: Prisma.RoleOrderByWithRelationInput = {};
      if (sortBy === 'name') {
        orderBy.name = sortOrder;
      } else if (sortBy === 'updatedAt') {
        orderBy.updatedAt = sortOrder;
      } else {
        orderBy.createdAt = sortOrder;
      }

      const [roles, total] = await Promise.all([
        prisma.role.findMany({
          where,
          orderBy,
          skip: offset,
          take: limit,
          include: {
            _count: {
              select: { userRoles: true },
            },
          },
        }),
        prisma.role.count({ where }),
      ]);

      return { roles, total };
    } catch (error) {
      logError(error as Error, { operation: 'searchRoles', params });
      throw error;
    }
  }

  /**
   * Assign role to user
   */
  static async assignRoleToUser(userId: string, roleId: string): Promise<void> {
    try {
      // Check if assignment already exists
      const existingAssignment = await prisma.userRole.findFirst({
        where: {
          userId,
          roleId,
        },
      });

      if (existingAssignment) {
        throw new Error('User already has this role');
      }

      await prisma.userRole.create({
        data: {
          userId,
          roleId,
        },
      });

      // Publish event
      logBusiness('Role assigned to user', 'userRole', `${userId}-${roleId}`, undefined, {
        userId,
        roleId,
      });

      // Clear relevant caches
      const userCacheKey = generateCacheKey('user', userId);
      const roleCacheKey = generateCacheKey('role', roleId);
      logCache('DEL', userCacheKey);
      logCache('DEL', roleCacheKey);
    } catch (error) {
      logError(error as Error, { operation: 'assignRoleToUser', userId, roleId });
      throw error;
    }
  }

  /**
   * Remove role from user
   */
  static async removeRoleFromUser(userId: string, roleId: string): Promise<void> {
    try {
      const userRole = await prisma.userRole.findFirst({
        where: {
          userId,
          roleId,
        },
      });

      if (!userRole) {
        throw new Error('User role assignment not found');
      }

      await prisma.userRole.delete({
        where: {
          id: userRole.id,
        },
      });

      // Publish event
      logBusiness('Role removed from user', 'userRole', `${userId}-${roleId}`, undefined, {
        userId,
        roleId,
      });

      // Clear relevant caches
      const userCacheKey = generateCacheKey('user', userId);
      const roleCacheKey = generateCacheKey('role', roleId);
      logCache('DEL', userCacheKey);
      logCache('DEL', roleCacheKey);
    } catch (error) {
      logError(error as Error, { operation: 'removeRoleFromUser', userId, roleId });
      throw error;
    }
  }

  /**
   * Get user roles
   */
  static async getUserRoles(userId: string): Promise<Role[]> {
    try {
      const userRoles = await prisma.userRole.findMany({
        where: { userId },
        include: {
          role: true,
        },
      });

      return userRoles.map(ur => ur.role);
    } catch (error) {
      logError(error as Error, { operation: 'getUserRoles', userId });
      throw error;
    }
  }

  /**
   * Get role users
   */
  static async getRoleUsers(roleId: string): Promise<any[]> {
    try {
      const userRoles = await prisma.userRole.findMany({
        where: { roleId },
        include: {
          user: {
            select: {
              id: true,
              username: true,
              email: true,
              firstName: true,
              lastName: true,
              isActive: true,
              createdAt: true,
            },
          },
        },
      });

      return userRoles.map(ur => ur.user);
    } catch (error) {
      logError(error as Error, { operation: 'getRoleUsers', roleId });
      throw error;
    }
  }
}

export default RoleService;
