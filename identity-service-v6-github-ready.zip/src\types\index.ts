/**
 * Type definitions for Identity Service
 */

import { Request } from 'express';

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  meta?: PaginationMeta;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
  hasNext: boolean;
  hasPrev: boolean;
}

export interface ValidationError {
  field: string;
  message: string;
  value?: any;
}

// User Types
export interface User {
  id: string;
  username: string;
  email: string;
  firstName?: string;
  lastName?: string;
  isActive: boolean;
  lastLoginAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateUserInput {
  username: string;
  email: string;
  password: string;
  firstName?: string;
  lastName?: string;
}

export interface UpdateUserInput {
  username?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  isActive?: boolean;
}

export interface UserWithRoles extends User {
  userRoles: Array<{
    role: Role;
  }>;
}

// Role Types
export interface Role {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateRoleInput {
  name: string;
  description?: string;
}

export interface UpdateRoleInput {
  name?: string;
  description?: string;
  isActive?: boolean;
}

export interface RoleWithUsers extends Role {
  userRoles: Array<{
    user: User;
  }>;
}

// Group Types
export interface Group {
  id: string;
  name: string;
  description?: string;
  isPrivate: boolean;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateGroupInput {
  name: string;
  description?: string;
  isPrivate?: boolean;
}

export interface UpdateGroupInput {
  name?: string;
  description?: string;
  isPrivate?: boolean;
  isActive?: boolean;
}

export interface GroupWithMembers extends Group {
  groupMembers: Array<{
    user: User;
    membershipType?: MembershipType;
    isActive: boolean;
    joinedAt: Date;
  }>;
}

// GroupMember Types
export interface GroupMember {
  id: string;
  userId: string;
  groupId: string;
  membershipTypeId?: string;
  isActive: boolean;
  joinedAt: Date;
}

export interface CreateGroupMemberInput {
  userId: string;
  groupId: string;
  membershipTypeId?: string;
}

export interface UpdateGroupMemberInput {
  membershipTypeId?: string;
  isActive?: boolean;
}

// MembershipType Types
export interface MembershipType {
  id: string;
  name: string;
  description?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateMembershipTypeInput {
  name: string;
  description?: string;
}

export interface UpdateMembershipTypeInput {
  name?: string;
  description?: string;
  isActive?: boolean;
}

// UserRole Types
export interface UserRole {
  id: string;
  userId: string;
  roleId: string;
}

export interface CreateUserRoleInput {
  userId: string;
  roleId: string;
}

// Auth Types
export interface LoginInput {
  username: string;
  password: string;
}

export interface RefreshTokenInput {
  refreshToken: string;
}

export interface ChangePasswordInput {
  currentPassword: string;
  newPassword: string;
}

export interface ResetPasswordInput {
  token: string;
  newPassword: string;
}

export interface LoginResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface TokenResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface AuthToken {
  id: string;
  userId: string;
  token: string;
  tokenType: string; // Changed from TokenType enum to string for simplicity
  expiresAt: Date;
  isRevoked: boolean;
  createdAt: Date;
}

// TokenType enum for future authentication enhancement
// export enum TokenType {
//   ACCESS = 'ACCESS',
//   REFRESH = 'REFRESH',
//   RESET_PASSWORD = 'RESET_PASSWORD',
//   PASSWORD_RESET = 'PASSWORD_RESET',
//   EMAIL_VERIFICATION = 'EMAIL_VERIFICATION',
// }

export interface JwtPayload {
  userId: string;
  username: string;
  email: string;
  roles: string[];
  iat?: number;
  exp?: number;
  iss?: string;
}

// Extended Request Types
export interface AuthenticatedRequest extends Request {
  user?: User;
  token?: string;
}

export interface PaginatedRequest extends Request {
  pagination?: {
    page: number;
    limit: number;
    sortBy: string;
    sortOrder: 'asc' | 'desc';
    offset: number;
  };
}

// Query Types
export interface PaginationQuery {
  page?: string;
  limit?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface UserQuery extends PaginationQuery {
  search?: string;
  isActive?: string;
  role?: string;
}

export interface RoleQuery extends PaginationQuery {
  search?: string;
  isActive?: string;
}

export interface GroupQuery extends PaginationQuery {
  search?: string;
  isActive?: string;
  isPrivate?: string;
}

// Audit Log Types
export interface AuditLog {
  id: string;
  entityType: string;
  entityId: string;
  action: string;
  oldValues?: any;
  newValues?: any;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
  createdAt: Date;
}

export interface CreateAuditLogInput {
  entityType: string;
  entityId: string;
  action: string;
  oldValues?: any;
  newValues?: any;
  userId?: string;
  ipAddress?: string;
  userAgent?: string;
}

// Service Response Types
export interface ServiceResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  statusCode?: number;
}

// Event Types for Kafka
export interface EventPayload {
  eventType: string;
  entityType: string;
  entityId: string;
  userId?: string;
  data?: any;
  timestamp: Date;
}

export default {};
