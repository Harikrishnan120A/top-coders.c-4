/**
 * Role Controller for Identity Service
 * Handles all role-related HTTP requests with unique name enforcement,
 * comprehensive validation, error handling, and API documentation
 */

import { Response } from 'express';
import { validationResult, body, param, query } from 'express-validator';
import { PrismaClient, Prisma } from '@prisma/client';

import {
  AuthenticatedRequest,
  CreateRoleInput,
  UpdateRoleInput,
  RoleQuery,
} from '../types';
import {
  sendSuccess,
  sendError,
  sendValidationError,
  parsePaginationQuery,
  getPaginationMeta,
  getOffset,
  getClientIp,
  getUserAgent,
} from '../utils/helpers';
import {
  HTTP_STATUS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  VALIDATION_CONSTANTS,
} from '../utils/constants';
import {
  logBusiness,
  logError,
  logValidation,
} from '../utils/logger';

const prisma = new PrismaClient();

/**
 * @swagger
 * components:
 *   schemas:
 *     Role:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *           description: Unique identifier for the role
 *         name:
 *           type: string
 *           description: Role name (unique across system)
 *         description:
 *           type: string
 *           description: Role description
 *         isActive:
 *           type: boolean
 *           description: Whether the role is active
 *         createdAt:
 *           type: string
 *           format: date-time
 *           description: Role creation timestamp
 *         updatedAt:
 *           type: string
 *           format: date-time
 *           description: Last update timestamp
 *     CreateRoleRequest:
 *       type: object
 *       required:
 *         - name
 *       properties:
 *         name:
 *           type: string
 *           minLength: 2
 *           maxLength: 50
 *           description: Unique role name
 *         description:
 *           type: string
 *           maxLength: 500
 *           description: Role description
 */

export class RoleController {
  /**
   * @swagger
   * /api/v1/roles:
   *   get:
   *     summary: Get all roles with pagination and filtering
   *     tags: [Roles]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: query
   *         name: page
   *         schema:
   *           type: integer
   *           minimum: 1
   *           default: 1
   *         description: Page number
   *       - in: query
   *         name: limit
   *         schema:
   *           type: integer
   *           minimum: 1
   *           maximum: 100
   *           default: 20
   *         description: Number of items per page
   *       - in: query
   *         name: search
   *         schema:
   *           type: string
   *         description: Search term for role name or description
   *       - in: query
   *         name: isActive
   *         schema:
   *           type: boolean
   *         description: Filter by active status
   *       - in: query
   *         name: sortBy
   *         schema:
   *           type: string
   *           enum: [name, createdAt, updatedAt]
   *           default: createdAt
   *         description: Field to sort by
   *       - in: query
   *         name: sortOrder
   *         schema:
   *           type: string
   *           enum: [asc, desc]
   *           default: desc
   *         description: Sort order
   *     responses:
   *       200:
   *         description: List of roles retrieved successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                   example: true
   *                 data:
   *                   type: array
   *                   items:
   *                     $ref: '#/components/schemas/Role'
   *                 meta:
   *                   $ref: '#/components/schemas/PaginationMeta'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async getRoles(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { page, limit, sortBy, sortOrder } = parsePaginationQuery(req.query);
      const { search, isActive } = req.query as RoleQuery;
      const offset = getOffset(page, limit);

      // Build where clause for filtering
      const where: any = {};

      if (search) {
        where.OR = [
          { name: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } },
        ];
      }

      if (isActive !== undefined) {
        where.isActive = isActive === 'true';
      }

      // Get roles with pagination
      const [roles, total] = await Promise.all([
        prisma.role.findMany({
          where,
          orderBy: { [sortBy]: sortOrder },
          skip: offset,
          take: limit,
          include: {
            _count: {
              select: {
                userRoles: true,
              },
            },
          },
        }),
        prisma.role.count({ where }),
      ]);

      // Add user count to each role
      const rolesWithCount = roles.map(role => ({
        id: role.id,
        name: role.name,
        description: role.description ?? undefined,
        isActive: role.isActive,
        createdAt: role.createdAt,
        updatedAt: role.updatedAt,
        userCount: role._count.userRoles,
      }));

      const meta = getPaginationMeta(page, limit, total);

      logBusiness('getRoles', 'role', 'list', req.user?.id, {
        total,
        page,
        limit,
        search,
        isActive,
      });

      sendSuccess(res, rolesWithCount, 'Roles retrieved successfully', HTTP_STATUS.OK, meta);
    } catch (error: any) {
      logError(error, { action: 'getRoles' }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/roles/{id}:
   *   get:
   *     summary: Get role by ID
   *     tags: [Roles]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema:
   *           type: string
   *         description: Role ID
   *     responses:
   *       200:
   *         description: Role retrieved successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                   example: true
   *                 data:
   *                   allOf:
   *                     - $ref: '#/components/schemas/Role'
   *                     - type: object
   *                       properties:
   *                         users:
   *                           type: array
   *                           items:
   *                             $ref: '#/components/schemas/User'
   *       404:
   *         $ref: '#/components/responses/NotFound'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async getRoleById(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { id } = req.params;

      const role = await prisma.role.findUnique({
        where: { id },
        include: {
          userRoles: {
            include: {
              user: {
                select: {
                  id: true,
                  username: true,
                  email: true,
                  firstName: true,
                  lastName: true,
                  isActive: true,
                  createdAt: true,
                  updatedAt: true,
                },
              },
            },
            where: {
              user: {
                isActive: true,
              },
            },
          },
        },
      });

      if (!role) {
        logBusiness('getRoleById', 'role', id, req.user?.id, undefined, ERROR_MESSAGES.ROLE_NOT_FOUND);
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.ROLE_NOT_FOUND);
        return;
      }

      // Format response with users list
      const roleWithUsers = {
        id: role.id,
        name: role.name,
        description: role.description ?? undefined,
        isActive: role.isActive,
        createdAt: role.createdAt,
        updatedAt: role.updatedAt,
        users: role.userRoles.map(ur => ({
          ...ur.user,
          firstName: ur.user.firstName ?? undefined,
          lastName: ur.user.lastName ?? undefined,
        })),
        userCount: role.userRoles.length,
      };

      logBusiness('getRoleById', 'role', id, req.user?.id);
      sendSuccess(res, roleWithUsers, 'Role retrieved successfully');
    } catch (error: any) {
      logError(error, { action: 'getRoleById', roleId: req.params.id }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/roles:
   *   post:
   *     summary: Create a new role with unique name constraint
   *     tags: [Roles]
   *     security:
   *       - bearerAuth: []
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             $ref: '#/components/schemas/CreateRoleRequest'
   *     responses:
   *       201:
   *         description: Role created successfully
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                   example: true
   *                 data:
   *                   $ref: '#/components/schemas/Role'
   *                 message:
   *                   type: string
   *                   example: Role created successfully
   *       400:
   *         $ref: '#/components/responses/BadRequest'
   *       409:
   *         description: Role name already exists
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 success:
   *                   type: boolean
   *                   example: false
   *                 message:
   *                   type: string
   *                   example: Role name already exists
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async createRole(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        const validationErrors = errors.array().map(err => ({
          field: err.type === 'field' ? (err as any).path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? (err as any).value : undefined,
        }));

        validationErrors.forEach(error => {
          logValidation(error.field, error.value, error.message, req.user?.id);
        });

        sendValidationError(res, validationErrors);
        return;
      }

      const roleData: CreateRoleInput = req.body;

      try {
        // Create role - Prisma will enforce unique constraint
        const newRole = await prisma.role.create({
          data: {
            name: roleData.name,
            description: roleData.description,
          },
        });

        // Convert null to undefined for response
        const sanitizedRole = {
          ...newRole,
          description: newRole.description ?? undefined,
        };

        // Log audit trail
        await prisma.auditLog.create({
          data: {
            entityType: 'role',
            entityId: newRole.id,
            action: 'create',
            newValues: sanitizedRole,
            userId: req.user?.id,
            ipAddress: getClientIp(req),
            userAgent: getUserAgent(req),
          },
        });

        logBusiness('createRole', 'role', newRole.id, req.user?.id, { name: newRole.name });
        sendSuccess(res, sanitizedRole, SUCCESS_MESSAGES.ROLE_CREATED, HTTP_STATUS.CREATED);

      } catch (error: any) {
        // Handle unique constraint violation
        if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
          logBusiness('createRole', 'role', 'create_conflict', req.user?.id, {
            attemptedName: roleData.name,
            error: ERROR_MESSAGES.DUPLICATE_ROLE_NAME,
          });
          sendError(res, HTTP_STATUS.CONFLICT, ERROR_MESSAGES.DUPLICATE_ROLE_NAME);
          return;
        }
        throw error; // Re-throw other errors
      }

    } catch (error: any) {
      logError(error, { action: 'createRole', roleData: req.body }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/roles/{id}:
   *   put:
   *     summary: Update role by ID with unique name validation
   *     tags: [Roles]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema:
   *           type: string
   *         description: Role ID
   *     requestBody:
   *       required: true
   *       content:
   *         application/json:
   *           schema:
   *             type: object
   *             properties:
   *               name:
   *                 type: string
   *                 minLength: 2
   *                 maxLength: 50
   *               description:
   *                 type: string
   *                 maxLength: 500
   *               isActive:
   *                 type: boolean
   *     responses:
   *       200:
   *         description: Role updated successfully
   *       404:
   *         $ref: '#/components/responses/NotFound'
   *       409:
   *         description: Role name already exists
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async updateRole(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const updateData: UpdateRoleInput = req.body;

      // Validate request
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        const validationErrors = errors.array().map(err => ({
          field: err.type === 'field' ? (err as any).path : 'unknown',
          message: err.msg,
          value: err.type === 'field' ? (err as any).value : undefined,
        }));
        sendValidationError(res, validationErrors);
        return;
      }

      // Check if role exists
      const existingRole = await prisma.role.findUnique({
        where: { id },
      });

      if (!existingRole) {
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.ROLE_NOT_FOUND);
        return;
      }

      try {
        // Update role - Prisma will enforce unique constraint
        const updatedRole = await prisma.role.update({
          where: { id },
          data: updateData,
        });

        // Convert null to undefined
        const sanitizedRole = {
          ...updatedRole,
          description: updatedRole.description ?? undefined,
        };

        const sanitizedExistingRole = {
          ...existingRole,
          description: existingRole.description ?? undefined,
        };

        // Log audit trail
        await prisma.auditLog.create({
          data: {
            entityType: 'role',
            entityId: id,
            action: 'update',
            oldValues: sanitizedExistingRole,
            newValues: sanitizedRole,
            userId: req.user?.id,
            ipAddress: getClientIp(req),
            userAgent: getUserAgent(req),
          },
        });

        logBusiness('updateRole', 'role', id, req.user?.id, { changes: updateData });
        sendSuccess(res, sanitizedRole, SUCCESS_MESSAGES.ROLE_UPDATED);

      } catch (error: any) {
        // Handle unique constraint violation
        if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
          logBusiness('updateRole', 'role', id, req.user?.id, {
            attemptedName: updateData.name,
            error: ERROR_MESSAGES.DUPLICATE_ROLE_NAME,
          });
          sendError(res, HTTP_STATUS.CONFLICT, ERROR_MESSAGES.DUPLICATE_ROLE_NAME);
          return;
        }
        throw error; // Re-throw other errors
      }

    } catch (error: any) {
      logError(error, { action: 'updateRole', roleId: req.params.id }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/roles/{id}:
   *   delete:
   *     summary: Delete role by ID
   *     tags: [Roles]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema:
   *           type: string
   *         description: Role ID
   *     responses:
   *       204:
   *         description: Role deleted successfully
   *       404:
   *         $ref: '#/components/responses/NotFound'
   *       400:
   *         description: Cannot delete role with assigned users
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async deleteRole(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { id } = req.params;

      // Check if role exists
      const existingRole = await prisma.role.findUnique({
        where: { id },
        include: {
          _count: {
            select: {
              userRoles: true,
            },
          },
        },
      });

      if (!existingRole) {
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.ROLE_NOT_FOUND);
        return;
      }

      // Check if role has assigned users
      if (existingRole._count.userRoles > 0) {
        logBusiness('deleteRole', 'role', id, req.user?.id, undefined, 'Cannot delete role with assigned users');
        sendError(res, HTTP_STATUS.BAD_REQUEST, 'Cannot delete role with assigned users');
        return;
      }

      // Delete the role
      await prisma.role.delete({ where: { id } });

      // Log audit trail
      await prisma.auditLog.create({
        data: {
          entityType: 'role',
          entityId: id,
          action: 'delete',
          oldValues: {
            ...existingRole,
            description: existingRole.description ?? undefined,
          },
          userId: req.user?.id,
          ipAddress: getClientIp(req),
          userAgent: getUserAgent(req),
        },
      });

      logBusiness('deleteRole', 'role', id, req.user?.id, { name: existingRole.name });
      sendSuccess(res, undefined, SUCCESS_MESSAGES.ROLE_DELETED, HTTP_STATUS.NO_CONTENT);
    } catch (error: any) {
      logError(error, { action: 'deleteRole', roleId: req.params.id }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }

  /**
   * @swagger
   * /api/v1/roles/{id}/users:
   *   get:
   *     summary: Get users assigned to a specific role
   *     tags: [Roles]
   *     security:
   *       - bearerAuth: []
   *     parameters:
   *       - in: path
   *         name: id
   *         required: true
   *         schema:
   *           type: string
   *         description: Role ID
   *       - in: query
   *         name: page
   *         schema:
   *           type: integer
   *           minimum: 1
   *           default: 1
   *       - in: query
   *         name: limit
   *         schema:
   *           type: integer
   *           minimum: 1
   *           maximum: 100
   *           default: 20
   *     responses:
   *       200:
   *         description: Users with role retrieved successfully
   *       404:
   *         $ref: '#/components/responses/NotFound'
   *       401:
   *         $ref: '#/components/responses/Unauthorized'
   *       500:
   *         $ref: '#/components/responses/InternalError'
   */
  static async getRoleUsers(req: AuthenticatedRequest, res: Response): Promise<void> {
    try {
      const { id } = req.params;
      const { page, limit } = parsePaginationQuery(req.query);
      const offset = getOffset(page, limit);

      // Check if role exists
      const role = await prisma.role.findUnique({
        where: { id },
        select: { id: true, name: true },
      });

      if (!role) {
        sendError(res, HTTP_STATUS.NOT_FOUND, ERROR_MESSAGES.ROLE_NOT_FOUND);
        return;
      }

      // Get users with this role
      const [userRoles, total] = await Promise.all([
        prisma.userRole.findMany({
          where: { roleId: id },
          include: {
            user: {
              select: {
                id: true,
                username: true,
                email: true,
                firstName: true,
                lastName: true,
                isActive: true,
                createdAt: true,
                updatedAt: true,
              },
            },
          },
          skip: offset,
          take: limit,
        }),
        prisma.userRole.count({ where: { roleId: id } }),
      ]);

      const users = userRoles.map(ur => ({
        ...ur.user,
        firstName: ur.user.firstName ?? undefined,
        lastName: ur.user.lastName ?? undefined,
      }));

      const meta = getPaginationMeta(page, limit, total);

      logBusiness('getRoleUsers', 'role', id, req.user?.id, { userCount: total });
      sendSuccess(res, users, 'Role users retrieved successfully', HTTP_STATUS.OK, meta);
    } catch (error: any) {
      logError(error, { action: 'getRoleUsers', roleId: req.params.id }, req.user?.id);
      sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, ERROR_MESSAGES.INTERNAL_ERROR);
    }
  }
}

// Validation middleware for role operations
export const validateCreateRole = [
  body('name')
    .isLength({ min: VALIDATION_CONSTANTS.MIN_ROLE_NAME_LENGTH, max: VALIDATION_CONSTANTS.MAX_ROLE_NAME_LENGTH })
    .withMessage(`Role name must be between ${VALIDATION_CONSTANTS.MIN_ROLE_NAME_LENGTH} and ${VALIDATION_CONSTANTS.MAX_ROLE_NAME_LENGTH} characters`)
    .matches(/^[a-zA-Z0-9_\s-]+$/)
    .withMessage('Role name can only contain letters, numbers, underscores, spaces, and hyphens')
    .trim(),

  body('description')
    .optional()
    .isLength({ max: 500 })
    .withMessage('Description must not exceed 500 characters')
    .trim(),
];

export const validateUpdateRole = [
  param('id').isUUID().withMessage('Invalid role ID format'),

  body('name')
    .optional()
    .isLength({ min: VALIDATION_CONSTANTS.MIN_ROLE_NAME_LENGTH, max: VALIDATION_CONSTANTS.MAX_ROLE_NAME_LENGTH })
    .withMessage(`Role name must be between ${VALIDATION_CONSTANTS.MIN_ROLE_NAME_LENGTH} and ${VALIDATION_CONSTANTS.MAX_ROLE_NAME_LENGTH} characters`)
    .matches(/^[a-zA-Z0-9_\s-]+$/)
    .withMessage('Role name can only contain letters, numbers, underscores, spaces, and hyphens')
    .trim(),

  body('description')
    .optional()
    .isLength({ max: 500 })
    .withMessage('Description must not exceed 500 characters')
    .trim(),

  body('isActive')
    .optional()
    .isBoolean()
    .withMessage('isActive must be a boolean value'),
];

export const validateRoleParams = [
  param('id').isUUID().withMessage('Invalid role ID format'),
];

export const validateRoleQuery = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('search').optional().isLength({ max: 100 }).withMessage('Search term too long'),
  query('isActive').optional().isBoolean().withMessage('isActive must be a boolean'),
  query('sortBy').optional().isIn(['name', 'createdAt', 'updatedAt']).withMessage('Invalid sort field'),
  query('sortOrder').optional().isIn(['asc', 'desc']).withMessage('Sort order must be asc or desc'),
];
