/**
 * Authentication Service for Identity Service
 * Business logic for authentication and token management
 */

import jwt, { SignOptions } from 'jsonwebtoken';
import { PrismaClient, User } from '@prisma/client';
import { comparePassword } from '../utils/helpers';
import { logAuth, logError, logBusiness } from '../utils/logger';
import config from '../config';

const prisma = new PrismaClient();

export interface TokenPayload {
  userId: string;
  username: string;
  email: string;
  roles: string[];
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export class AuthService {
  /**
   * Authenticate user with username/email and password
   */
  static async authenticate(
    usernameOrEmail: string,
    password: string,
    ip?: string,
  ): Promise<{ user: User; tokens: AuthTokens } | null> {
    try {
      // Find user by username or email
      const user = await prisma.user.findFirst({
        where: {
          OR: [
            { username: usernameOrEmail },
            { email: usernameOrEmail },
          ],
          isActive: true,
        },
        include: {
          userRoles: {
            include: {
              role: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
        },
      });

      if (!user) {
        logAuth('login_failed', undefined, usernameOrEmail, ip, false, 'User not found');
        return null;
      }

      // Verify password
      const isPasswordValid = await comparePassword(password, user.password);
      if (!isPasswordValid) {
        logAuth('login_failed', user.id, user.username, ip, false, 'Invalid password');
        return null;
      }

      // Generate tokens
      const roles = user.userRoles.map(ur => ur.role.name);
      const tokens = await this.generateTokens({
        userId: user.id,
        username: user.username,
        email: user.email,
        roles,
      });

      // Update last login
      await prisma.user.update({
        where: { id: user.id },
        data: {
          lastLoginAt: new Date(),
        },
      });

      // Log successful authentication
      logAuth('login_success', user.id, user.username, ip, true);
      logBusiness('User authenticated', 'user', user.id, user.id, {
        username: user.username,
        ip,
      });

      return { user, tokens };
    } catch (error) {
      logError(error as Error, { operation: 'authenticate', usernameOrEmail });
      throw error;
    }
  }

  /**
   * Generate access and refresh tokens
   */
  static async generateTokens(payload: TokenPayload): Promise<AuthTokens> {
    try {
      const accessTokenOptions: SignOptions = {
        expiresIn: config.jwt.expiresIn as any,
        issuer: 'topcoder-identity-service',
      };

      const refreshTokenOptions: SignOptions = {
        expiresIn: config.jwt.refreshExpiresIn as any,
        issuer: 'topcoder-identity-service',
      };

      const accessToken = jwt.sign(payload, config.jwt.secret, accessTokenOptions);
      const refreshToken = jwt.sign({ userId: payload.userId }, config.jwt.refreshSecret, refreshTokenOptions);

      // Store refresh token in database
      await this.storeRefreshToken(payload.userId, refreshToken);

      // Calculate expiration time in seconds
      const expiresInHours = parseInt(config.jwt.expiresIn.replace('h', ''));
      const expiresIn = expiresInHours * 3600; // Convert hours to seconds

      return {
        accessToken,
        refreshToken,
        expiresIn,
      };
    } catch (error) {
      logError(error as Error, { operation: 'generateTokens', userId: payload.userId });
      throw error;
    }
  }

  /**
   * Refresh access token using refresh token
   */
  static async refreshToken(refreshToken: string): Promise<AuthTokens | null> {
    try {
      // Verify refresh token
      const decoded = jwt.verify(refreshToken, config.jwt.refreshSecret) as { userId: string };

      // Check if refresh token exists and is valid
      const storedToken = await prisma.authToken.findFirst({
        where: {
          userId: decoded.userId,
          token: refreshToken,
          tokenType: 'REFRESH',
          expiresAt: {
            gt: new Date(),
          },
          isRevoked: false,
        },
      });

      if (!storedToken) {
        return null;
      }

      // Get user with roles
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        include: {
          userRoles: {
            include: {
              role: {
                select: {
                  name: true,
                },
              },
            },
          },
        },
      });

      if (!user || !user.isActive) {
        return null;
      }

      // Generate new tokens
      const roles = user.userRoles.map(ur => ur.role.name);
      const tokens = await this.generateTokens({
        userId: user.id,
        username: user.username,
        email: user.email,
        roles,
      });

      // Invalidate old refresh token
      await this.invalidateRefreshToken(refreshToken);

      logBusiness('Token refreshed', 'user', user.id, user.id);

      return tokens;
    } catch (error) {
      logError(error as Error, { operation: 'refreshToken' });
      return null;
    }
  }

  /**
   * Verify access token
   */
  static async verifyAccessToken(token: string): Promise<TokenPayload | null> {
    try {
      const decoded = jwt.verify(token, config.jwt.secret) as TokenPayload;

      // Verify user still exists and is active
      const user = await prisma.user.findUnique({
        where: { id: decoded.userId },
        select: { isActive: true },
      });

      if (!user || !user.isActive) {
        return null;
      }

      return decoded;
    } catch {
      return null;
    }
  }

  /**
   * Logout user by invalidating refresh token
   */
  static async logout(userId: string, refreshToken?: string): Promise<void> {
    try {
      if (refreshToken) {
        await this.invalidateRefreshToken(refreshToken);
      } else {
        // Invalidate all refresh tokens for user
        await prisma.authToken.updateMany({
          where: {
            userId,
            tokenType: 'REFRESH',
          },
          data: {
            isRevoked: true,
            expiresAt: new Date(),
          },
        });
      }

      logAuth('logout', userId, undefined, undefined, true);
      logBusiness('User logged out', 'user', userId, userId);
    } catch (error) {
      logError(error as Error, { operation: 'logout', userId });
      throw error;
    }
  }

  /**
   * Store refresh token in database
   */
  private static async storeRefreshToken(userId: string, token: string): Promise<void> {
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days

    // Delete existing refresh tokens for this user
    await prisma.authToken.deleteMany({
      where: {
        userId,
        tokenType: 'REFRESH',
      },
    });

    // Create new refresh token
    await prisma.authToken.create({
      data: {
        userId,
        token,
        tokenType: 'REFRESH',
        expiresAt,
      },
    });
  }

  /**
   * Invalidate refresh token
   */
  private static async invalidateRefreshToken(token: string): Promise<void> {
    await prisma.authToken.updateMany({
      where: {
        token,
        tokenType: 'REFRESH',
      },
      data: {
        isRevoked: true,
        expiresAt: new Date(),
      },
    });
  }

  /**
   * Clean up expired refresh tokens
   */
  static async cleanupExpiredTokens(): Promise<void> {
    try {
      await prisma.authToken.deleteMany({
        where: {
          OR: [
            {
              expiresAt: {
                lt: new Date(),
              },
            },
            {
              isRevoked: true,
            },
          ],
        },
      });

      logBusiness('Expired tokens cleaned up', 'system', 'cleanup');
    } catch (error) {
      logError(error as Error, { operation: 'cleanupExpiredTokens' });
    }
  }

  /**
   * Change user password
   */
  static async changePassword(
    userId: string,
    currentPassword: string,
    newPassword: string,
  ): Promise<boolean> {
    try {
      const user = await prisma.user.findUnique({
        where: { id: userId },
        select: { password: true },
      });

      if (!user) {
        return false;
      }

      // Verify current password
      const isCurrentPasswordValid = await comparePassword(currentPassword, user.password);
      if (!isCurrentPasswordValid) {
        return false;
      }

      // Update password
      const hashedNewPassword = await require('../utils/helpers').hashPassword(newPassword);
      await prisma.user.update({
        where: { id: userId },
        data: {
          password: hashedNewPassword,
          updatedAt: new Date(),
        },
      });

      // Invalidate all refresh tokens to force re-login
      await prisma.authToken.updateMany({
        where: {
          userId,
          tokenType: 'REFRESH',
        },
        data: {
          isRevoked: true,
          expiresAt: new Date(),
        },
      });

      logBusiness('Password changed', 'user', userId, userId);

      return true;
    } catch (error) {
      logError(error as Error, { operation: 'changePassword', userId });
      throw error;
    }
  }
}

export default AuthService;
