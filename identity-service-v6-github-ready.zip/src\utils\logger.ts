/**
 * Logger utility for structured logging
 */

import { createLogger, format, transports, Logger } from 'winston';
import config from '../config';

const { combine, timestamp, errors, json, colorize, printf } = format;

// Custom format for console output
const consoleFormat = printf(({ level, message, timestamp, ...meta }: any) => {
  let log = `${timestamp} [${level}]: ${message}`;

  if (Object.keys(meta).length > 0) {
    log += ` ${JSON.stringify(meta)}`;
  }

  return log;
});

// Create logger instance
const logger: Logger = createLogger({
  level: config.logging.level,
  format: combine(
    timestamp(),
    errors({ stack: true }),
    json(),
  ),
  defaultMeta: {
    service: 'identity-service',
    version: process.env.npm_package_version || '1.0.0',
  },
  transports: [
    // File transport for all logs
    new transports.File({
      filename: 'logs/error.log',
      level: 'error',
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
    new transports.File({
      filename: 'logs/combined.log',
      maxsize: 5242880, // 5MB
      maxFiles: 5,
    }),
  ],
  // Don't exit on handled exceptions
  exitOnError: false,
});

// Add console transport for non-production environments
if (config.nodeEnv !== 'production') {
  logger.add(new transports.Console({
    format: combine(
      colorize(),
      timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
      consoleFormat,
    ),
  }));
}

/**
 * Log API request
 */
export const logRequest = (
  method: string,
  url: string,
  statusCode: number,
  responseTime: number,
  userId?: string,
  ip?: string,
): void => {
  logger.info('API Request', {
    method,
    url,
    statusCode,
    responseTime,
    userId,
    ip,
    type: 'api_request',
  });
};

/**
 * Log authentication event
 */
export const logAuth = (
  event: string,
  userId?: string,
  username?: string,
  ip?: string,
  success: boolean = true,
  error?: string,
): void => {
  logger.info('Authentication Event', {
    event,
    userId,
    username,
    ip,
    success,
    error,
    type: 'auth_event',
  });
};

/**
 * Log database operation
 */
export const logDatabase = (
  operation: string,
  table: string,
  recordId?: string,
  userId?: string,
  duration?: number,
  error?: string,
): void => {
  const level = error ? 'error' : 'debug';

  logger.log(level, 'Database Operation', {
    operation,
    table,
    recordId,
    userId,
    duration,
    error,
    type: 'db_operation',
  });
};

/**
 * Log cache operation
 */
export const logCache = (
  operation: string,
  key: string,
  hit: boolean = false,
  ttl?: number,
  error?: string,
): void => {
  const level = error ? 'error' : 'debug';

  logger.log(level, 'Cache Operation', {
    operation,
    key,
    hit,
    ttl,
    error,
    type: 'cache_operation',
  });
};

/**
 * Log Kafka event
 */
export const logKafka = (
  event: string,
  topic: string,
  partition?: number,
  offset?: string,
  error?: string,
): void => {
  const level = error ? 'error' : 'info';

  logger.log(level, 'Kafka Event', {
    event,
    topic,
    partition,
    offset,
    error,
    type: 'kafka_event',
  });
};

/**
 * Log business logic event
 */
export const logBusiness = (
  action: string,
  entityType: string,
  entityId: string,
  userId?: string,
  details?: any,
  error?: string,
): void => {
  const level = error ? 'error' : 'info';

  logger.log(level, 'Business Event', {
    action,
    entityType,
    entityId,
    userId,
    details,
    error,
    type: 'business_event',
  });
};

/**
 * Log security event
 */
export const logSecurity = (
  event: string,
  severity: 'low' | 'medium' | 'high' | 'critical',
  userId?: string,
  ip?: string,
  details?: any,
): void => {
  logger.warn('Security Event', {
    event,
    severity,
    userId,
    ip,
    details,
    type: 'security_event',
  });
};

/**
 * Log performance metric
 */
export const logPerformance = (
  operation: string,
  duration: number,
  details?: any,
): void => {
  logger.info('Performance Metric', {
    operation,
    duration,
    details,
    type: 'performance',
  });
};

/**
 * Log error with context
 */
export const logError = (
  error: Error,
  context?: any,
  userId?: string,
): void => {
  logger.error('Application Error', {
    message: error.message,
    stack: error.stack,
    context,
    userId,
    type: 'application_error',
  });
};

/**
 * Log validation error
 */
export const logValidation = (
  field: string,
  value: any,
  error: string,
  userId?: string,
): void => {
  logger.warn('Validation Error', {
    field,
    value: typeof value === 'string' ? value : JSON.stringify(value),
    error,
    userId,
    type: 'validation_error',
  });
};

/**
 * Log configuration change
 */
export const logConfig = (
  setting: string,
  oldValue: any,
  newValue: any,
  userId?: string,
): void => {
  logger.info('Configuration Change', {
    setting,
    oldValue,
    newValue,
    userId,
    type: 'config_change',
  });
};

/**
 * Create child logger with additional context
 */
export const createChildLogger = (context: any): Logger => {
  return logger.child(context);
};

/**
 * Log startup information
 */
export const logStartup = (port: number, environment: string): void => {
  logger.info('Application Started', {
    port,
    environment,
    timestamp: new Date().toISOString(),
    type: 'startup',
  });
};

/**
 * Log shutdown information
 */
export const logShutdown = (reason: string): void => {
  logger.info('Application Shutdown', {
    reason,
    timestamp: new Date().toISOString(),
    type: 'shutdown',
  });
};

export default logger;
