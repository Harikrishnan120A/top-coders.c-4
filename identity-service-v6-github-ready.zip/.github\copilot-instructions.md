<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

# Identity Service v6 - Custom Instructions for GitHub Copilot

This is a TypeScript-based Identity Service project that migrates from Java/MySQL to TypeScript/PostgreSQL using Prisma ORM.

## Project Overview
- **Purpose**: Authentication and identity management service for Topcoder platform
- **Technology Stack**: Node.js, TypeScript, Express, PostgreSQL, Prisma, Redis, Kafka
- **Architecture**: RESTful API with microservices patterns

## Code Style Guidelines
1. Use TypeScript strict mode with proper type definitions
2. Follow RESTful API conventions
3. Implement proper error handling with standardized error responses
4. Use Prisma for database operations
5. Implement comprehensive logging using structured logging
6. Follow dependency injection patterns for services
7. Use environment variables for configuration
8. Implement proper validation using express-validator

## Key Requirements
- Replace hardcoded values with constants from a centralized constants file
- Ensure unique role names are enforced at database level
- Add comprehensive API documentation using Swagger
- Maintain Redis caching for performance
- Implement Kafka event publishing for system integration
- Achieve 90%+ test coverage
- Fix all linting errors

## File Structure Conventions
- Controllers: Handle HTTP requests/responses, validation, and route handling
- Services: Business logic implementation
- Models: Prisma schema and type definitions
- Middleware: Authentication, authorization, error handling
- Utils: Helper functions and utilities
- Config: Configuration management and constants

## Important Notes
- Always use the centralized constants file instead of magic numbers
- Implement proper error handling with status codes from constants
- Add JSDoc comments to all API methods
- Use proper TypeScript types for all function parameters and return values
- Follow the existing naming conventions for consistency
