/**
 * Main application entry point for Identity Service v6
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import { PrismaClient } from '@prisma/client';

import config, { validateConfig } from './config';
import logger, { logStartup, logShutdown } from './utils/logger';
import { HTTP_STATUS, ERROR_MESSAGES } from './utils/constants';
import { sendError } from './utils/helpers';

// Import routes
import userRoutes from './routes/user.routes';
import roleRoutes from './routes/role.routes';
import groupRoutes from './routes/group.routes';
import authRoutes from './routes/auth.routes';
// import authRoutes from './routes/auth.routes'; // Will be created later

const app = express();
const prisma = new PrismaClient();

/**
 * Initialize application
 */
const initializeApp = async (): Promise<void> => {
  try {
    // Validate configuration
    validateConfig();

    // Connect to database
    await prisma.$connect();
    logger.info('Database connected successfully');

    // Setup middleware
    setupMiddleware();

    // Setup routes
    setupRoutes();

    // Setup error handling
    setupErrorHandling();

    // Start server
    const server = app.listen(config.port, () => {
      logStartup(config.port, config.nodeEnv);
    });

    // Graceful shutdown
    setupGracefulShutdown(server);

  } catch (error) {
    logger.error('Failed to initialize application:', error);
    process.exit(1);
  }
};

/**
 * Setup middleware
 */
const setupMiddleware = (): void => {
  // Security middleware
  app.use(helmet());

  // CORS
  app.use(cors(config.cors));

  // Rate limiting
  app.use(rateLimit({
    windowMs: config.rateLimit.windowMs,
    max: config.rateLimit.max,
    message: {
      success: false,
      message: 'Too many requests from this IP, please try again later.',
    },
    standardHeaders: true,
    legacyHeaders: false,
  }));

  // Logging
  app.use(morgan(config.logging.format, {
    stream: {
      write: (message: string) => {
        logger.info(message.trim());
      },
    },
  }));

  // Body parsing
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // Health check
  app.get('/health', (req, res) => {
    res.status(HTTP_STATUS.OK).json({
      success: true,
      message: 'Identity Service is healthy',
      timestamp: new Date().toISOString(),
      version: process.env.npm_package_version || '1.0.0',
    });
  });
};

/**
 * Setup routes
 */
const setupRoutes = (): void => {
  // API routes
  app.use('/api/v1/auth', authRoutes);
  app.use('/api/v1/users', userRoutes);
  app.use('/api/v1/roles', roleRoutes);
  app.use('/api/v1/groups', groupRoutes);

  // Swagger documentation (if enabled)
  if (config.features.enableSwagger) {
    // Will setup Swagger later
  }

  // 404 handler
  app.use('*', (req, res) => {
    sendError(res, HTTP_STATUS.NOT_FOUND, 'Route not found');
  });
};

/**
 * Setup error handling
 */
const setupErrorHandling = (): void => {
  // Global error handler - ignoring next parameter as it's required by Express middleware signature
  // eslint-disable-next-line @typescript-eslint/no-unused-vars, no-unused-vars
  app.use((error: any, req: express.Request, res: express.Response, _next: express.NextFunction) => {
    logger.error('Unhandled error:', error);

    // Don't leak error details in production
    const message = config.nodeEnv === 'production'
      ? ERROR_MESSAGES.INTERNAL_ERROR
      : error.message;

    sendError(res, HTTP_STATUS.INTERNAL_SERVER_ERROR, message);
  });

  // Handle unhandled promise rejections
  process.on('unhandledRejection', (reason: any, promise: Promise<any>) => {
    logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
    // Don't exit process in production
    if (config.nodeEnv !== 'production') {
      process.exit(1);
    }
  });

  // Handle uncaught exceptions
  process.on('uncaughtException', (error: Error) => {
    logger.error('Uncaught Exception:', error);
    logShutdown('Uncaught Exception');
    process.exit(1);
  });
};

/**
 * Setup graceful shutdown
 */
const setupGracefulShutdown = (server: any): void => {
  const gracefulShutdown = (signal: string) => {
    logger.info(`Received ${signal}. Graceful shutdown initiated...`);

    server.close(async () => {
      try {
        // Close database connection
        await prisma.$disconnect();
        logger.info('Database connection closed');

        logShutdown(`Graceful shutdown via ${signal}`);
        process.exit(0);
      } catch (error) {
        logger.error('Error during shutdown:', error);
        process.exit(1);
      }
    });

    // Force shutdown after 30 seconds
    setTimeout(() => {
      logger.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 30000);
  };

  // Listen for shutdown signals
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
};

// Start the application
if (require.main === module) {
  initializeApp();
}

export { app, prisma };
export default app;
